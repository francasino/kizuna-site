const COURSE_DATA = {
  "modules": [
    {
      "id": 0,
      "title": "Introducción, Metodología y Aval Normativo"
    },
    {
      "id": 1,
      "title": "Identidad Digital y Validez Jurídica"
    },
    {
      "id": 2,
      "title": "Psicología del Ataque y Shadow AI"
    },
    {
      "id": 3,
      "title": "Protección de Datos 360"
    },
    {
      "id": 4,
      "title": "Seguridad en el Entorno Híbrido"
    },
    {
      "id": 5,
      "title": "Protocolo de Respuesta ante Incidentes"
    },
    {
      "id": 6,
      "title": "Salud Mental y Ética Digital"
    },
    {
      "id": 7,
      "title": "Gestión de Vulnerabilidades y Brechas"
    }
  ],
  "slides": [
    {
      "module_id": 0,
      "slide_num_str": "Diapositiva 1",
      "title": "Bienvenida y Objetivos del Curso",
      "visual_title": "Bienvenidos: Prevención de Riesgos Digitales (PRD)",
      "text_on_screen": [
        "• Bienvenido al programa de capacitación integral en Prevención de Riesgos Digitales.",
        "• Nuestro objetivo: Transformar el eslabón humano, tradicionalmente el más atacado, en el escudo más fuerte de la organización (el \"Human Firewall\").",
        "• Este no es un curso técnico sobre informática; es un programa sobre decisiones diarias, comportamiento, ética digital y cumplimiento legal."
      ],
      "extended_text": [
        "\"Bienvenidos.",
        "Tradicionalmente, hemos delegado la seguridad de nuestras empresas a los departamentos técnicos y a complejos programas informáticos. Sin embargo, la inmensa mayoría de los incidentes de seguridad y fugas de datos no ocurren por fallos en las máquinas, sino por errores humanos. Un clic apresurado, un correo malinterpretado o una contraseña compartida son suficientes para comprometer toda la infraestructura.",
        "Este curso aborda la seguridad desde una perspectiva humana, cognitiva y legal. Hemos diseñado este programa no solo para proteger los activos de la empresa, sino para dotarles de herramientas que protejan su propia identidad, su responsabilidad legal como trabajadores y su tranquilidad en el entorno digital y remoto.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Introducción, Metodología y Aval Normativo",
      "time": 60,
      "id": 0
    },
    {
      "module_id": 0,
      "slide_num_str": "Diapositiva 2",
      "title": "Metodología de Estudio (Instrucciones)",
      "visual_title": "Cómo realizar este curso: Metodología y Tiempos",
      "text_on_screen": [
        "• Aprendizaje a tu ritmo, pero sin atajos: El sistema de formación (LMS) registrará tu progreso y tiempo de lectura.",
        "• Tiempos mínimos: Cada diapositiva y texto tiene asignado un tiempo mínimo de permanencia. El objetivo es asimilar, no memorizar ni correr.",
        "• Contenido Extendido: El texto bajo cada diapositiva es de lectura obligatoria. Contiene los matices legales y ejemplos prácticos necesarios para superar los cuestionarios.",
        "• Evaluaciones bloqueantes: Al final de cada módulo encontrarás un \"Quiz\". Debes superarlo para poder avanzar al siguiente bloque."
      ],
      "extended_text": [
        "\"Para garantizar la eficacia de esta formación y su validez ante auditorías externas, el curso ha sido diseñado bajo una metodología de 'asimilación controlada'. Esto significa que el sistema registrará el tiempo que inviertes en cada sección. No intentes saltar rápidamente las diapositivas; el sistema tiene un tiempo mínimo estipulado para asegurar la lectura comprensiva. Te pedimos que leas detenidamente el contenido extendido de cada pantalla. Las normativas que vamos a tratar (como el RGPD o el Código Penal) son complejas, pero las hemos traducido a situaciones de tu día a día en la oficina. Tómate el tiempo necesario para reflexionar sobre tus propios hábitos digitales antes de enfrentarte a los cuestionarios de evaluación que bloquean el paso entre módulos.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Introducción, Metodología y Aval Normativo",
      "time": 60,
      "id": 1
    },
    {
      "module_id": 0,
      "slide_num_str": "Diapositiva 3",
      "title": "Mapa del Curso (Visión General)",
      "visual_title": "¿Qué vamos a aprender? El Mapa del Curso",
      "text_on_screen": [
        "• Módulo 1: Identidad Digital y Validez Jurídica (El fin de la contraseña compartida).",
        "• Módulo 2: Psicología del Ataque y Shadow AI (Cómo hackean tu mente y el peligro de las IAs públicas).",
        "• Módulo 3: Protección de Datos 360 (RGPD, LOPDGDD y los Derechos ARSOPOL).",
        "• Módulo 4: Seguridad en el Entorno Híbrido (El teletrabajo y tu red doméstica).",
        "• Módulo 5: Protocolo de Respuesta ante Incidentes (La Regla de Oro y la cadena de custodia).",
        "• Módulo 6: Salud Mental y Ética Digital (Desconexión digital y cultura de 'No Culpa').",
        "• Módulo 7: Gestión de Vulnerabilidades y Brechas (El límite operativo y el protocolo de las 72 horas)."
      ],
      "extended_text": [
        "\"El curso está estructurado de forma secuencial, yendo desde tu propia identidad hasta cómo manejar una crisis a nivel corporativo. Empezaremos entendiendo el peso legal de tus credenciales (Módulo 1) y cómo los cibercriminales utilizan la psicología y la Inteligencia Artificial para engañarte (Módulo 2). Posteriormente, entraremos en el núcleo legal de la privacidad de datos (Módulo 3) y cómo proteger esa información cuando trabajas desde casa (Módulo 4). Finalmente, te prepararemos para lo peor: sabrás exactamente qué hacer en los primeros 5 minutos de un ataque (Módulo 5), cómo cuidar tu salud mental ante la presión tecnológica (Módulo 6) y los pasos legales ineludibles si sufrimos una brecha de datos (Módulo 7).\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Introducción, Metodología y Aval Normativo",
      "time": 60,
      "id": 2
    },
    {
      "module_id": 0,
      "slide_num_str": "Diapositiva 4",
      "title": "Resumen Ejecutivo de Cumplimiento (Matriz Legal)",
      "visual_title": "Ámbito",
      "text_on_screen": [
        "Normativa Principal",
        "Identidad y Firma",
        "eIDAS 2.0, RD-ley 6/2023, Código Penal",
        "Seguridad e IA",
        "NIS2, AI Act, ISO 27001, CRA",
        "Privacidad y Datos",
        "RGPD, LOPDGDD, ENS",
        "Entorno Laboral",
        "Ley 10/2021, Ley 31/1995 (PRL), Ley 2/2023",
        "Salud Mental y Ética",
        "LOPDGDD, AI Act, PRL",
        "Gestión de Crisis y Brechas",
        "RGPD, NIS2, ENS"
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Introducción, Metodología y Aval Normativo",
      "time": 60,
      "id": 3
    },
    {
      "module_id": 0,
      "slide_num_str": "Diapositiva 5",
      "title": "Aval Normativo y Auditoría (Parte I - Privacidad y Seguridad)  Justificación de Compliance y Auditoría (I)",
      "visual_title": "",
      "text_on_screen": [
        "• RGPD y LOPDGDD: Evidencia el cumplimiento de la Responsabilidad Proactiva y formación obligatoria en tratamiento de datos y brechas.",
        "• Directiva NIS2: Cumplimiento del Artículo 21.2 sobre la obligatoriedad de impartir capacitación en ciberhigiene básica.",
        "• ENS (RD 311/2022): Marco de seguridad para servicios con el sector público que exige niveles estrictos de trazabilidad y control.",
        "• CRA (Cyber Resilience Act): Norma de ciberresiliencia europea que obliga al uso de productos y software 'seguros por diseño'."
      ],
      "extended_text": [
        "\"Desde el punto de vista del Compliance corporativo, tu participación en este curso genera un registro (log) que la empresa utilizará ante las autoridades en caso de auditoría o inspección. Por un lado, cubrimos frontalmente las exigencias de la Agencia Española de Protección de Datos (AEPD) al brindar la formación continua en el manejo de información confidencial. Por otro lado, damos respuesta a la estricta Directiva Europea NIS2, que obliga a las empresas, bajo amenaza de sanción directa a sus directivos, a implementar políticas de formación en ciberhigiene y a educar a la plantilla en las amenazas actuales, como la ingeniería social y el phishing.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Introducción, Metodología y Aval Normativo",
      "time": 60,
      "id": 4
    },
    {
      "module_id": 0,
      "slide_num_str": "Diapositiva 6",
      "title": "Aval Normativo y Auditoría (Parte II - Nacional, Laboral y Ética)",
      "visual_title": "Justificación de Compliance y Auditoría (II)",
      "text_on_screen": [
        "• Código Penal (Art. 31 bis): Integra la formación en el Modelo de Prevención de Delitos, atenuando la responsabilidad de la persona jurídica.",
        "• Ley de Trabajo a Distancia (Ley 10/2021): Instrucción obligatoria sobre seguridad de la información en entornos remotos.",
        "• Ley de PRL (Ley 31/1995) y Desconexión Digital: Abordaje de riesgos psicosociales (tecnoestrés) y respeto al descanso.",
        "• Ley 2/2023: Establece el marco de protección del informante y el canal de denuncias contra negligencias sistemáticas.",
        "• ISO 27001 (Control A.7.2.2): Certifica la toma de conciencia del personal respecto a las políticas de seguridad de la información.",
        "• AI Act: Regulación ética para el uso de Inteligencia Artificial, asegurando la supervisión humana y la transparencia algorítmica."
      ],
      "extended_text": [
        "\"El abanico legislativo que cubrimos con este programa es extenso. A nivel del Código Penal español, este curso demuestra que la empresa tiene controles reales para evitar delitos informáticos desde dentro. Para quienes teletrabajan, el contenido incluye instrucciones de seguridad exigidas por la Ley de Trabajo a Distancia. Además, al abordar la cultura de la 'No culpa', la desconexión digital y el tecnoestrés, nos alineamos con los requerimientos de Prevención de Riesgos Laborales. Finalmente, de cara a certificaciones de calidad internacionales, este curso las reglas básicas de seguridad de la información corporativa.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Introducción, Metodología y Aval Normativo",
      "time": 60,
      "id": 5
    },
    {
      "module_id": 0,
      "slide_num_str": "Diapositiva 6",
      "title": "Glosario de Términos Clave (I) - La Amenaza y el Factor Humano",
      "visual_title": "Glosario (I): Comprendiendo el Ecosistema y la Amenaza",
      "text_on_screen": [
        "• Human Firewall (Cortafuegos Humano): El concepto de que los empleados, debidamente formados y concienciados, son la capa de seguridad más efectiva de una organización frente a los ciberataques.",
        "• Ingeniería Social: Técnicas de manipulación psicológica utilizadas por los ciberdelincuentes para engañar a los usuarios y conseguir que revelen información confidencial o realicen acciones peligrosas.",
        "• Ransomware: Tipo de software malicioso (malware) que cifra o bloquea el acceso a los archivos y sistemas de la empresa, exigiendo un rescate económico para devolver la operatividad."
      ],
      "extended_text": [
        "\"Antes de adentrarnos en los módulos específicos, es fundamental que hablemos el mismo idioma. A lo largo de este curso, utilizaremos términos que definen tanto las amenazas a las que nos enfrentamos como las defensas que vamos a construir. El término más importante de todo este programa es el 'Human Firewall'. Los atacantes saben que vulnerar la mente de un empleado mediante 'Ingeniería Social' es mucho más fácil que romper los algoritmos y la criptografía de nuestros servidores. La ingeniería social adopta muchas formas (correos, mensajes, llamadas), pero su objetivo final suele ser el mismo: inyectar un ‘malware’, el virus que secuestra nuestra información y puede paralizar por completo la empresa. Al asimilar este glosario, empezamos a construir ese cortafuegos humano.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Introducción, Metodología y Aval Normativo",
      "time": 60,
      "id": 6
    },
    {
      "module_id": 0,
      "slide_num_str": "Diapositiva 7",
      "title": "Glosario de Términos Clave (II) - Comportamiento y Tecnología",
      "visual_title": "Glosario (II): Higiene, Hábitos y Tecnología",
      "text_on_screen": [
        "• Ciberhigiene: Conjunto de rutinas y buenas prácticas diarias (como actualizar equipos o no reutilizar contraseñas) necesarias para mantener la seguridad de los dispositivos y las redes.",
        "• MFA (Autenticación Multifactor): Medida de seguridad obligatoria que requiere dos o más pruebas de identidad (ej. contraseña + código en el móvil) para acceder a un sistema.",
        "• Shadow IT / Shadow AI: El uso de aplicaciones, software o Inteligencias Artificiales de terceros por parte de los empleados sin el conocimiento ni la autorización del departamento de informática."
      ],
      "extended_text": [
        "\"En nuestra interacción diaria con la tecnología, nuestros hábitos lo son todo. La 'Ciberhigiene' no es un evento puntual, sino el mantenimiento constante de nuestra salud digital. Una parte vital de esa higiene es el 'MFA', una sigla que verás constantemente. El MFA es lo que garantiza que, aunque un ciberdelincuente robe tu contraseña, no pueda acceder a la red corporativa porque no tiene tu teléfono móvil para confirmar el acceso. Por otro lado, debemos conocer a nuestro enemigo interno: el 'Shadow IT' y su variante moderna, el 'Shadow AI'. Buscar atajos utilizando conversores de PDF gratuitos o IAs públicas para procesar datos de la empresa parece inofensivo, pero expone información confidencial fuera de nuestro control y destruye las garantías de privacidad de la organización.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Introducción, Metodología y Aval Normativo",
      "time": 60,
      "id": 7
    },
    {
      "module_id": 0,
      "slide_num_str": "Diapositiva 8",
      "title": "Glosario de Términos Clave (III) - Marco Normativo",
      "visual_title": "Glosario (III): Cumplimiento y Legalidad Corporativa",
      "text_on_screen": [
        "• Diligencia Debida: El deber legal del empleado de actuar con el cuidado, la prudencia y la responsabilidad que exige su puesto de trabajo en el manejo de la información y los activos digitales.",
        "• Derechos ARSOPOL: Acrónimo de los derechos digitales de los ciudadanos sobre sus datos (Acceso, Rectificación, Supresión, Oposición, Portabilidad y Limitación).",
        "• Whistleblowing (Canal de Denuncias): Herramienta corporativa obligatoria, segura y confidencial para que cualquier empleado pueda reportar malas prácticas, abusos o vulnerabilidades sin temor a represalias."
      ],
      "extended_text": [
        "\"Finalmente, nuestro vocabulario legal. En el entorno jurídico actual, la buena intención no basta; la ley exige 'Diligencia Debida'. Este concepto será tu escudo legal: los protocolos que veremos en este curso te pueden proteger frente a responsabilidades civiles o penales en caso de un incidente complejo. Esa diligencia se aplica especialmente al tratar con los datos de personas, cuyo control reside en los 'Derechos ARSOPOL'. La empresa no es dueña de los datos, solo su custodia temporal. Para garantizar que todo el ecosistema funcione de manera ética, contamos con canales de 'Whistleblowing', un término anglosajón que hace referencia a la protección del informante. Si observas que se vulneran las normativas, este mecanismo te permite levantar la mano con garantías absolutas de confidencialidad e impunidad.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Introducción, Metodología y Aval Normativo",
      "time": 60,
      "id": 8
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 6",
      "title": "Definición y Evolución de la Identidad Digital (El eIDAS 2.0)",
      "visual_title": "",
      "text_on_screen": [
        "• Identidad Digital: En el entorno laboral, ya no es solo un nombre de usuario y una contraseña; es el conjunto de atributos que permite a un trabajador actuar en nombre de una organización con plena validez jurídica.",
        "• Identificación vs. Firma: La identificación consiste en demostrar quién eres ante un sistema. La firma electrónica, en cambio, es la manifestación de voluntad y autorización de trámites que vinculan legalmente a la empresa.",
        "• El Estándar eIDAS 2.0: Europa ha consolidado las \"Carteras de Identidad Digital\" (EUDI Wallets). La identidad es estrictamente personal e intransferible. El uso compartido de credenciales anula el principio de \"No repudio\"."
      ],
      "extended_text": [
        "\"Durante años, hemos considerado el 'usuario y contraseña' como un simple trámite administrativo para encender el ordenador o acceder al correo. Esta visión ha quedado completamente obsoleta. Hoy, bajo el marco europeo eIDAS 2.0 y las normativas nacionales, la identidad digital es el activo más crítico de la empresa.",
        "Debemos diferenciar claramente dos acciones. Cuando te identificas, el sistema simplemente sabe que estás ahí. Pero cuando utilizas una firma electrónica, estás manifestando la voluntad de tu empresa; estás firmando contratos o autorizando transferencias que tienen un peso legal absoluto.",
        "Con la llegada de las Carteras de Identidad Digital Europeas, debemos erradicar por completo el concepto de 'cuentas genéricas' o contraseñas compartidas. En el entorno jurídico actual, impera el principio de 'No repudio': si un sistema registra una acción bajo tu identidad digital, la ley asume automáticamente que la has realizado tú y no podrás negarlo. Si compartes tus credenciales, estás cediendo tu capacidad de firmar y autorizar, lo cual constituye una brecha de seguridad grave.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 60,
      "id": 9
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 7",
      "title": "La Justicia Digital, el \"Punto de No Retorno\" y el ENS",
      "visual_title": "Relación con la Administración: Decreto Ómnibus y el ENS",
      "text_on_screen": [
        "• El 'Decreto Ómnibus' (RD-ley 6/2023): Establece la obligatoriedad de la relación digital para las personas jurídicas y sus representantes.",
        "• Sedes Electrónicas: Obligación de gestionar notificaciones a través de la Sede Judicial Electrónica y la Carpeta Ciudadana. Todo clic activa plazos legales automáticos.",
        "• Esquema Nacional de Seguridad (ENS - RD 311/2022): Si la empresa presta servicios al Sector Público, las identidades digitales corporativas están sometidas a controles auditables y obligatorios de trazabilidad."
      ],
      "extended_text": [
        "\"La digitalización de la Administración en España ha alcanzado un hito histórico. Con la entrada en vigor del Real Decreto-ley 6/2023, conocido como el 'Decreto Ómnibus', la relación de las empresas con la Administración (incluyendo la de Justicia) deja de ser en papel para convertirse en obligatoriamente digital.",
        "Las notificaciones ya no llegan mediante un cartero, sino a buzones digitales específicos. En el momento en que alguien con acceso hace clic para abrir esa notificación, el sistema registra que la empresa ha sido notificada oficialmente, disparando automáticamente los plazos legales. Ignorar una notificación en el buzón digital supone cruzar un 'Punto de No Retorno', pudiendo derivar en multas severas o la pérdida de juicios.",
        "Además, si nuestra empresa tiene contratos con Ayuntamientos o Ministerios, estamos sujetos al Esquema Nacional de Seguridad (ENS). Esta ley nos exige demostrar en todo momento qué empleado específico realizó cada trámite. Utilizar cuentas de correo departamentales compartidas (ej. 'administracion@empresa.com') para acceder a sedes públicas es una vulneración directa del ENS.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 60,
      "id": 10
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 8",
      "title": "La Trampa de la \"Firma Compartida\" (Custodia Legal)",
      "visual_title": "El Certificado Digital y los Riesgos de la Cesión de Firma",
      "text_on_screen": [
        "• El Certificado Digital (FNMT, DNIe o EUDI Wallet) es la llave maestra de la empresa. Bajo el nuevo marco legal, su custodia es responsabilidad estricta del titular.",
        "• Los Riesgos de la \"Cesión de Firma\" (La práctica de prestar las claves a un compañero para \"agilizar trámites\"):",
        "Responsabilidad Civil: Daños económicos causados por una firma no autorizada.",
        "Responsabilidad Penal: Posibilidad de imputación por falsedad documental o suplantación de identidad.",
        "Nulidad de Actuaciones: La Administración puede anular trámites e invalidar contratos si detecta que la firma no fue realizada por el titular legítimo."
      ],
      "extended_text": [
        "\"Hablemos de una de las prácticas más peligrosas y, lamentablemente, más normalizadas en los entornos administrativos: prestar el certificado digital o la tarjeta criptográfica a un compañero porque el titular está de vacaciones, o dejarlo instalado en un ordenador sin contraseña de uso. Bajo el prisma de la eficiencia, parece una acción inofensiva; bajo el prisma de la ley, es una gravísima 'Cesión de Firma'.",
        "Al ceder tu certificado, estás delegando tu identidad legal completa. Si ese compañero comete un error en un documento público, aprueba una compra indebida, o si un ciberdelincuente compromete el equipo en ese momento, las repercusiones recaen sobre el titular original. Esto puede traducirse en Responsabilidad Civil e incluso en Responsabilidad Penal, enfrentando cargos por falsedad documental. Además, la urgencia nunca justifica la violación de la custodia legal. Si el sistema detecta accesos simultáneos desde ubicaciones distintas con el mismo certificado, los trámites serán invalidados.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 60,
      "id": 11
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 9",
      "title": "El Fin de la Contraseña, la Era del MFA y el \"MFA Bombing\"",
      "visual_title": "",
      "text_on_screen": [
        "• Para cumplir con la Directiva NIS2, el MFA (Autenticación de Múltiples Factores) es una medida técnica obligatoria.",
        "• Requiere la combinación de dos de estos tres factores:",
        "Algo que sabes: (Ej. Contraseña o PIN).",
        "Algo que tienes: (Ej. Token físico, SMS o App Authenticator).",
        "Algo que eres: (Ej. Huella dactilar, biometría facial).",
        "• El Nuevo Riesgo: La Fatiga de MFA (MFA Bombing). Si recibes peticiones de aprobación en tu móvil que tú no has solicitado, NO las apruebes. Es un atacante intentando cansarte."
      ],
      "extended_text": [
        "\"El cerebro humano no está diseñado para recordar docenas de contraseñas largas y complejas. Los ciberdelincuentes lo saben; si una de tus contraseñas se filtra en internet, la usarán para acceder a la red corporativa. Por esto, la Directiva Europea NIS2 exige la adopción obligatoria de sistemas MFA.",
        "Debes demostrar quién eres combinando 'algo que sabes' con 'algo que tienes' o 'algo que eres'. Sin embargo, los hackers han desarrollado una nueva técnica llamada MFA Bombing o Fatiga de Notificaciones. Al robar tu contraseña, intentarán entrar al sistema repetidamente de madrugada, provocando que tu móvil reciba docenas de solicitudes de aprobación consecutivas. Su objetivo es que, por frustración, cansancio o despiste, acabes pulsando 'Aceptar' para que deje de sonar.",
        "Regla de oro: Jamás apruebes una solicitud de MFA en tu móvil si no eres tú quien está frente a la pantalla intentando iniciar sesión. Si esto ocurre, repórtalo inmediatamente.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 60,
      "id": 12
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 10",
      "title": "Responsabilidad Profesional y el Canal de Denuncias",
      "visual_title": "• Compliance Penal (Art. 31 bis): El comportamiento del empleado tiene consecuencias directas en la responsabilidad de la empresa.",
      "text_on_screen": [
        "• Tu Protocolo Diario (Reglas de Oro):",
        "Uso Exclusivo: Identidad corporativa solo para fines laborales.",
        "No Exposición: Prohibido anotar claves físicamente o en archivos de texto.",
        "• El Canal de Denuncias (Ley 2/2023): Tienes a tu disposición un canal oficial, anónimo y seguro para reportar prácticas peligrosas (ej. contraseñas compartidas en el departamento o exposición de certificados) sin riesgo de represalias."
      ],
      "extended_text": [
        "\"El entorno legislativo es implacable. El Artículo 31 bis del Código Penal establece que si una empresa permite malas prácticas y se produce una fuga de datos, se enfrenta a multas millonarias. Para blindarnos frente a responsabilidades, debemos interiorizar el Uso Exclusivo de la identidad y la No Exposición de las claves.",
        "Pero la ley va un paso más allá para protegerte a ti como empleado. Según la Ley 2/2023, y según el número de trabajadores y sector, la empresa debe implementar un Canal de Denuncias interno y obligatorio (Whistleblowing). Si observas que en tu departamento se están vulnerando los protocolos de identidad (por ejemplo, si un superior obliga a los empleados a compartir contraseñas o a dejar los certificados digitales instalados sin seguridad), tienes el deber ético y el derecho legal de utilizar este canal. La ley te garantiza un anonimato tecnológico absoluto y protección total contra cualquier tipo de represalia laboral. La seguridad es responsabilidad de todos.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 60,
      "id": 13
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 11",
      "title": "Quiz de Evaluación - Módulo 1 (Pregunta 1)",
      "visual_title": "Quiz Módulo 1: Supera la Evaluación",
      "text_on_screen": [
        "(Esta pantalla bloquea el avance del alumno en el LMS hasta que responda correctamente).",
        "Pregunta 1: De acuerdo con el estándar europeo eIDAS 2.0 y el principio de \"No repudio\", ¿qué ocurre si un compañero utiliza tu usuario y contraseña, con tu permiso, para aprobar un documento en el sistema de la empresa?",
        "• [A] Que el compañero asume toda la responsabilidad legal del documento.",
        "• [B] Que el sistema lo bloqueará automáticamente por ser un trámite compartido.",
        "• [C] Que la ley asume automáticamente que la firma la has realizado tú, recayendo sobre ti la responsabilidad legal y constituyendo una brecha de seguridad grave."
      ],
      "extended_text": [
        "(Selecciona tu respuesta para avanzar a la siguiente pregunta de evaluación)."
      ],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 45,
      "question_text": "De acuerdo con el estándar europeo eIDAS 2.0 y el principio de \"No repudio\", ¿qué ocurre si un compañero utiliza tu usuario y contraseña, con tu permiso, para aprobar un documento en el sistema de la empresa?",
      "options": [
        {
          "id": "A",
          "text": "Que el compañero asume toda la responsabilidad legal del documento."
        },
        {
          "id": "B",
          "text": "Que el sistema lo bloqueará automáticamente por ser un trámite compartido."
        },
        {
          "id": "C",
          "text": "Que la ley asume automáticamente que la firma la has realizado tú, recayendo sobre ti la responsabilidad legal y constituyendo una brecha de seguridad grave."
        }
      ],
      "correct_answer": "C",
      "feedback": "La identidad digital es intransferible. El principio de \"no repudio\" implica que no puedes negar legalmente una acción registrada con tus credenciales. Ceder tu firma te expone a responsabilidades civiles y penales. •",
      "id": 14
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 12",
      "title": "Quiz de Evaluación - Módulo 1 (Pregunta 2)",
      "visual_title": "Quiz Módulo 1: Supera la Evaluación (Pregunta 2)",
      "text_on_screen": [
        "Pregunta 2: Estás trabajando y de repente tu teléfono móvil corporativo recibe tres solicitudes consecutivas de MFA (Autenticación de Múltiples Factores) pidiendo que \"Apruebes\" un inicio de sesión, pero tú no estabas intentando acceder a nada. ¿Cómo debes actuar?",
        "• [A] Apruebo una de las solicitudes para que dejen de llegarme notificaciones al móvil y sigo trabajando.",
        "• [B] Rechazo las solicitudes inmediatamente y reporto el incidente al equipo de seguridad (IT), ya que estoy sufriendo un ataque de \"Fatiga MFA\" (MFA Bombing).",
        "• [C] Apago el teléfono y espero a que se solucione solo.",
        "• [D] Asumo que es un error de actualización de Windows y lo apruebo."
      ],
      "extended_text": [
        "(Selecciona tu respuesta para avanzar a la siguiente pregunta de evaluación)."
      ],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 45,
      "question_text": "Estás trabajando y de repente tu teléfono móvil corporativo recibe tres solicitudes consecutivas de MFA (Autenticación de Múltiples Factores) pidiendo que \"Apruebes\" un inicio de sesión, pero tú no estabas intentando acceder a nada. ¿Cómo debes actuar?",
      "options": [
        {
          "id": "A",
          "text": "Apruebo una de las solicitudes para que dejen de llegarme notificaciones al móvil y sigo trabajando."
        },
        {
          "id": "B",
          "text": "Rechazo las solicitudes inmediatamente y reporto el incidente al equipo de seguridad (IT), ya que estoy sufriendo un ataque de \"Fatiga MFA\" (MFA Bombing)."
        },
        {
          "id": "C",
          "text": "Apago el teléfono y espero a que se solucione solo."
        },
        {
          "id": "D",
          "text": "Asumo que es un error de actualización de Windows y lo apruebo."
        }
      ],
      "correct_answer": "B",
      "feedback": "El MFA Bombing es una técnica psicológica de los atacantes. Si recibes alertas de aprobación que no has generado, significa que el atacante ya tiene tu contraseña, pero el MFA le está bloqueando. Reportarlo es vital. •",
      "id": 15
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 13",
      "title": "Quiz de Evaluación - Módulo 1 (Pregunta 3)",
      "visual_title": "Quiz Módulo 1: Supera la Evaluación (Pregunta 3)",
      "text_on_screen": [
        "Pregunta 3: En el contexto de la relación con la Administración Pública (RD-ley 6/2023) y el Esquema Nacional de Seguridad (ENS), ¿qué consecuencia operativa tiene abrir una notificación en la Sede Electrónica Judicial y olvidar avisar al departamento responsable?",
        "• [A] Ninguna, porque al no haber respondido, la Administración no nos da por notificados oficialmente.",
        "• [B] El sistema nos dará un plazo extra de cortesía por ser una empresa privada.",
        "• [C] Cruzamos un \"Punto de No Retorno\". El simple clic registra la notificación oficial y dispara automáticamente los plazos legales, arriesgando multas severas o la pérdida de juicios."
      ],
      "extended_text": [
        "(Selecciona tu respuesta para avanzar a la última pregunta del módulo)."
      ],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 45,
      "question_text": "En el contexto de la relación con la Administración Pública (RD-ley 6/2023) y el Esquema Nacional de Seguridad (ENS), ¿qué consecuencia operativa tiene abrir una notificación en la Sede Electrónica Judicial y olvidar avisar al departamento responsable?",
      "options": [
        {
          "id": "A",
          "text": "Ninguna, porque al no haber respondido, la Administración no nos da por notificados oficialmente."
        },
        {
          "id": "B",
          "text": "El sistema nos dará un plazo extra de cortesía por ser una empresa privada."
        },
        {
          "id": "C",
          "text": "Cruzamos un \"Punto de No Retorno\". El simple clic registra la notificación oficial y dispara automáticamente los plazos legales, arriesgando multas severas o la pérdida de juicios."
        }
      ],
      "correct_answer": "C",
      "feedback": "La justicia digital no requiere firmas físicas para darse por notificada. El acceso al buzón genera un acuse de recibo técnico con presunción de veracidad absoluta que activa el reloj judicial. •",
      "id": 16
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 14",
      "title": "Quiz de Evaluación - Módulo 1 (Pregunta 4)",
      "visual_title": "Quiz Módulo 1: Supera la Evaluación (Pregunta 4)",
      "text_on_screen": [
        "Pregunta 4: Llegas nuevo a un departamento y notas que todos los compañeros comparten una misma contraseña y un certificado digital sin clave para enviar presupuestos, violando las políticas de seguridad. Tienes miedo de represalias si se lo dices al jefe del departamento. ¿Qué herramienta legal tienes a tu disposición?",
        "• [A] Adaptarme a la cultura del departamento para no causar problemas.",
        "• [B] Utilizar el Canal de Denuncias interno (Ley 2/2023), que garantiza mi anonimato absoluto y me protege legalmente frente a cualquier represalia laboral al reportar esta negligencia.",
        "• [C] Enviar un correo anónimo desde mi cuenta personal de Gmail a la dirección de la empresa."
      ],
      "extended_text": [
        "(Selecciona tu respuesta para ver el diagnóstico final y el feedback del Módulo 1)."
      ],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 45,
      "question_text": "Llegas nuevo a un departamento y notas que todos los compañeros comparten una misma contraseña y un certificado digital sin clave para enviar presupuestos, violando las políticas de seguridad. Tienes miedo de represalias si se lo dices al jefe del departamento. ¿Qué herramienta legal tienes a tu disposición?",
      "options": [
        {
          "id": "A",
          "text": "Adaptarme a la cultura del departamento para no causar problemas."
        },
        {
          "id": "B",
          "text": "Utilizar el Canal de Denuncias interno (Ley 2/2023), que garantiza mi anonimato absoluto y me protege legalmente frente a cualquier represalia laboral al reportar esta negligencia."
        },
        {
          "id": "C",
          "text": "Enviar un correo anónimo desde mi cuenta personal de Gmail a la dirección de la empresa."
        }
      ],
      "correct_answer": "B",
      "feedback": "La Ley 2/2023 obliga a empresas con características particulares a disponer de canales de \"Whistleblowing\". Denunciar negligencias graves de forma anónima es un derecho protegido que evita brechas de seguridad masivas y exime de responsabilidad a quien informa. \"Felicidades por completar el Módulo 1. Has comprendido que tu identidad digital es el equivalente jurídico a tu firma física, con todas sus implicaciones penales y administrativas. Dominar el uso de los factores de autenticación (MFA) y conocer tus derechos de reporte bajo la Ley 2/2023 son los primeros pasos para blindar tu puesto de trabajo. A continuación, en el Módulo 2, exploraremos cómo los cibercriminales intentan saltarse todas estas barreras tecnológicas hackeando directamente tu mente.\"",
      "id": 17
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 15",
      "title": "Resultados y Feedback del Módulo 1",
      "visual_title": "Corrección y Retroalimentación: Módulo 1",
      "text_on_screen": [
        "• Q1: Correcta [C] - Feedback: La identidad digital es intransferible. El principio de \"no repudio\" implica que no puedes negar legalmente una acción registrada con tus credenciales. Ceder tu firma te expone a responsabilidades civiles y penales.",
        "• Q2: Correcta [B] - Feedback: El MFA Bombing es una técnica psicológica de los atacantes. Si recibes alertas de aprobación que no has generado, significa que el atacante ya tiene tu contraseña, pero el MFA le está bloqueando. Reportarlo es vital.",
        "• Q3: Correcta [C] - Feedback: La justicia digital no requiere firmas físicas para darse por notificada. El acceso al buzón genera un acuse de recibo técnico con presunción de veracidad absoluta que activa el reloj judicial.",
        "• Q4: Correcta [B] - Feedback: La Ley 2/2023 obliga a empresas con características particulares a disponer de canales de \"Whistleblowing\". Denunciar negligencias graves de forma anónima es un derecho protegido que evita brechas de seguridad masivas y exime de responsabilidad a quien informa."
      ],
      "extended_text": [
        "\"Felicidades por completar el Módulo 1. Has comprendido que tu identidad digital es el equivalente jurídico a tu firma física, con todas sus implicaciones penales y administrativas. Dominar el uso de los factores de autenticación (MFA) y conocer tus derechos de reporte bajo la Ley 2/2023 son los primeros pasos para blindar tu puesto de trabajo. A continuación, en el Módulo 2, exploraremos cómo los cibercriminales intentan saltarse todas estas barreras tecnológicas hackeando directamente tu mente.\""
      ],
      "image_desc": null,
      "type": "quiz_feedback",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 0,
      "id": 18
    },
    {
      "module_id": 1,
      "slide_num_str": "Diapositiva 16",
      "title": "La Psicología del Ataque (El Modelo OCEAN)",
      "visual_title": "",
      "text_on_screen": [
        "• ¿Por qué evaluamos la personalidad? Los ciberdelincuentes no hackean solo sistemas, hackean personas.",
        "• Utilizamos el estándar psicológico OCEAN para identificar tu \"Punto Ciego\" cognitivo:",
        "O - Openness (Apertura a la experiencia)",
        "C - Conscientiousness (Responsabilidad / Minuciosidad)",
        "E - Extraversion (Extraversión)",
        "A - Agreeableness (Amabilidad / Empatía)",
        "N - Neuroticism (Neuroticismo / Estabilidad Emocional)",
        "No hay perfiles malos. Todo rasgo positivo tiene un vector de riesgo asociado."
      ],
      "extended_text": [
        "\"Entramos en la fase más crítica de este curso: el análisis de tu propia mente. Tradicionalmente, la seguridad se ha centrado en firewalls y contraseñas. Sin embargo, existe una delgada línea entre un comportamiento profesional eficiente y una vulnerabilidad crítica. Para defendernos, utilizamos el modelo psicológico OCEAN. Este modelo demuestra que nuestra personalidad determina cómo reaccionamos bajo presión. Por ejemplo, una persona con alta 'Extraversión' es excelente para las relaciones públicas, pero un atacante utilizará esa sociabilidad enviándole solicitudes falsas por LinkedIn para infiltrarse en la red corporativa. Conocer cuál de estas cinco dimensiones domina tu comportamiento te permitirá activar un 'freno cognitivo' justo antes de caer en la trampa.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Identidad Digital y Validez Jurídica",
      "time": 60,
      "id": 19
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 17",
      "title": "Instrucciones de la Autoevaluación",
      "visual_title": "Instrucciones: Descubre tu Código de Riesgo",
      "text_on_screen": [
        "• Formato: Verás 15 situaciones agrupadas en 5 bloques (A, B, C, D, E).",
        "• Cómo responder: Responde mentalmente SÍ o NO a cada afirmación. Debes ser brutalmente honesto; los resultados son anónimos y para tu propio autoconocimiento.",
        "• El Código: Anota en un papel la letra del bloque cada vez que tu respuesta instintiva sea \"SÍ\". La letra que más se repita formará tu Código de Vulnerabilidad Principal."
      ],
      "extended_text": [
        "\"Vamos a realizar un ejercicio de autoevaluación. Es fundamental entender que este no es un test de desempeño laboral. Es una herramienta de supervivencia digital. Hemos diseñado las preguntas exigiendo un 'SÍ' o un 'NO'.",
        "En el entorno digital, la duda o el 'depende' suele traducirse en un clic accidental. Lee cada situación y, si te sientes identificado con esa forma de actuar en tu día a día, anota la letra del bloque correspondiente. Si tienes un empate entre dos letras al final, significa que posees un perfil de riesgo mixto y deberás prestar atención a ambos vectores.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 20
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 18",
      "title": "El Cuestionario (Bloques A y B)",
      "visual_title": "Cuestionario de Comportamiento Digital (1/3)",
      "text_on_screen": [
        "• BLOQUE A (Amabilidad / Empatía):",
        "¿Te resulta muy incómodo decir \"no\" o ignorar a un compañero o cliente que te pide ayuda urgente por correo? (SÍ/NO)",
        "Si recibes un correo con el logo de un proveedor conocido, ¿asumes que es legítimo sin verificar la dirección exacta del remitente? (SÍ/NO)",
        "¿Te sentirías descortés si llamas por teléfono a un superior para confirmar si realmente te ha enviado un archivo adjunto? (SÍ/NO)",
        "• BLOQUE B (Baja Responsabilidad / Impulsividad):",
        "¿Trabajas habitualmente en modo \"multitarea\" (ej. leyendo correos mientras estás en una reunión o llamada)? (SÍ/NO)",
        "¿Sueles hacer clic rápidamente en \"Aceptar\" o \"Recordar más tarde\" en las ventanas emergentes (alertas, actualizaciones) para que no te molesten? (SÍ/NO)",
        "Cuando tienes prisa, ¿utilizas la misma contraseña del trabajo para registrarte en webs o servicios personales? (SÍ/NO)"
      ],
      "extended_text": [
        "\"El Bloque A mide tu nivel de complacencia. Ser servicial es maravilloso, pero en ciberseguridad, el exceso de confianza es la vía principal del Phishing. El Bloque B mide la falta de minuciosidad o impulsividad. La prisa y la multitarea son los mayores enemigos de la atención plena; cuando tu cerebro está saturado, automatiza el acto de hacer clic sin analizar el peligro.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 21
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 19",
      "title": "El Cuestionario (Bloques C y D)",
      "visual_title": "Cuestionario de Comportamiento Digital (2/3)",
      "text_on_screen": [
        "• BLOQUE C (Neuroticismo / Sensibilidad al Estrés):",
        "Si recibes un email de la alta dirección (CEO) o de una institución (Hacienda) exigiendo una acción inmediata, ¿sientes un pico de ansiedad que te impulsa a resolverlo en el acto? (SÍ/NO)",
        "¿Te preocupa tanto cometer un error que, si sospechas que has hecho clic en un virus, intentarías solucionarlo por tu cuenta antes de avisar a IT por miedo a una bronca? (SÍ/NO)",
        "¿Te sientes fácilmente abrumado y bloqueado cuando recibes demasiadas alertas de seguridad o correos en un mismo día? (SÍ/NO)",
        "• BLOQUE D (Apertura a la Experiencia / Curiosidad):",
        "¿Sueles utilizar aplicaciones gratuitas de internet (IA, conversores de PDF) para hacer tu trabajo más rápido, aunque la empresa no las haya autorizado (Shadow IT)? (SÍ / NO)",
        "Si ves un enlace llamativo o un código QR en la oficina, ¿sientes la curiosidad de escanearlo o abrirlo para ver de qué trata? (SÍ/NO)",
        "¿Crees que, al tener conocimientos informáticos medios-altos, es casi imposible que un hacker logre engañarte a ti? (SÍ/NO)"
      ],
      "extended_text": [
        "\"El Bloque C evalúa tu reactividad ante el estrés. Los ataques conocidos como 'Fraude del CEO' se basan en esto: generan un pánico artificial para que te saltes los protocolos por miedo a un castigo. El Bloque D evalúa la curiosidad y la temeridad. Los usuarios más innovadores y adaptables a menudo caen en la trampa de usar software no autorizado para ser más eficientes, creando fugas de datos sin darse cuenta.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 22
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 20",
      "title": "El Cuestionario (Bloque E) y Resultados",
      "visual_title": "Cuestionario (3/3) y Diagnóstico",
      "text_on_screen": [
        "• BLOQUE E (Extraversión / Sociabilidad):",
        "¿Sueles compartir fotos de tu puesto de trabajo, proyectos o viajes de empresa de forma pública en tus redes sociales? (SÍ/NO)",
        "¿Aceptas solicitudes de conexión en LinkedIn de personas de tu sector que no conoces, asumiendo que es bueno para el networking? (SÍ/NO)",
        "¿Hablas cómodamente sobre temas sensibles de la empresa o clientes mientras estás en lugares públicos (trenes, cafeterías) o teletrabajando en un coworking? (SÍ/NO)",
        "• TU DIAGNÓSTICO (Suma tus 'SÍ'):",
        "Mayoría de A: Perfil Complaciente (El Confiado)",
        "Mayoría de B: Perfil Impulsivo (El Despistado)",
        "Mayoría de C: Perfil Ansioso (El Reactivo)",
        "Mayoría de D: Perfil Temerario (El Curioso)",
        "Mayoría de E: Perfil Expuesto (El Sociable)"
      ],
      "extended_text": [
        "\"El Bloque E mide la extraversión y la sobreexposición. Los ciberdelincuentes utilizan técnicas de OSINT (Inteligencia de Fuentes Abiertas) para recopilar todo lo que publicas.",
        "Una simple foto de tu escritorio en Instagram puede revelar el software que usas, tu firma o los nombres de tus clientes, dándoles la munición perfecta para un ataque dirigido.",
        "Suma tus respuestas y avanza para conocer la regla de oro que debes aplicar según tu perfil principal.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 23
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 21",
      "title": "Perfil A - Complaciente / Alta Amabilidad",
      "visual_title": "• Tu Riesgo: Tu deseo de no incomodar te impide cuestionar solicitudes. Eres el blanco perfecto para suplantaciones de identidad (Spear Phishing).",
      "text_on_screen": [
        "• Tu Regla de Oro: La Desconfianza Educada. Verificar la identidad por teléfono no es una falta de respeto, es pura profesionalidad corporativa."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 24
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 22",
      "title": "Perfil B - Impulsivo / Baja Responsabilidad",
      "visual_title": "• Tu Riesgo: La velocidad anula tu capacidad de análisis. Al trabajar en piloto automático, eres vulnerable a correos que simulan notificaciones rutinarias falsas.",
      "text_on_screen": [
        "• Tu Regla de Oro: La Pausa de los 10 Segundos. Separa las manos del teclado antes de abrir un adjunto; ese tiempo permite a tu cerebro salir del modo multitarea y detectar el engaño."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 25
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 23",
      "title": "Perfil C - Ansioso / Alto Neuroticismo",
      "visual_title": "• Tu Riesgo: El miedo a represalias te bloquea y te vuelve susceptible a extorsiones, multas falsas o al \"Fraude del CEO\". Además, tiendes a ocultar los errores.",
      "text_on_screen": [
        "• Tu Regla de Oro: El Protocolo vence a la Jerarquía. Las reglas de seguridad están por encima de cualquier orden urgente de un jefe. Y recuerda: reportar un error nos salva; ocultarlo nos hunde."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 26
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 24",
      "title": "Perfil D - Temerario / Alta Apertura",
      "visual_title": "• Tu Riesgo: La arrogancia cognitiva y la curiosidad. Asumes que a ti no te van a engañar, lo que te lleva a usar herramientas IA no autorizadas o saltarte bloqueos de seguridad.",
      "text_on_screen": [
        "• Tu Regla de Oro: Zero Trust (Cero Confianza). No confíes ciegamente en tus instintos tecnológicos por encima de los controles de la empresa. Hasta los mayores expertos caen en trampas."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 27
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 25",
      "title": "Perfil E - Expuesto / Alta Extraversión",
      "visual_title": "• Tu Riesgo: Compartes demasiada información (Oversharing). Eres una mina de oro de información para que los atacantes fabriquen engaños extremadamente creíbles basados en tu vida.",
      "text_on_screen": [
        "• Tu Regla de Oro: El Escudo de la Privacidad. Antes de publicar una foto de la oficina o aceptar un contacto, asume que quien está al otro lado de la pantalla podría estar recopilando datos para atacar a tu organización."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 28
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 26",
      "title": "Anatomía de un Ataque (La \"Cyber Kill Chain\")",
      "visual_title": "Entiende las etapas clave de un ataque (Cyber Kill Chain)",
      "text_on_screen": [
        "• Los ciberataques no son instantáneos; siguen un proceso metódico conocido como Cyber Kill Chain (Cadena de Muerte Cibernética).",
        "• Fase 1 - Reconocimiento: El atacante investiga tu perfil, redes sociales y la estructura de tu empresa. (Aquí cae el Perfil E - Expuesto).",
        "• Fase 2 - Creación del Gancho: Diseña un mensaje altamente personalizado (Spear Phishing) para engañarte.",
        "• Fase 3 - Explotación: El éxito depende de tu acción (hacer clic o descargar). (Aquí caen los Perfiles A, B y C).",
        "• Fase 4 - Instalación: El código malicioso toma el control del equipo y busca datos sensibles o se propaga por la red."
      ],
      "extended_text": [
        "\"Para vencer a un atacante, debes entender cómo trabaja. Un ciberataque moderno sigue una metodología casi militar.",
        "Todo comienza con la fase de Reconocimiento, donde exploran fuentes públicas para recopilar datos. Si eres un 'Perfil Expuesto' (Alta Extraversión), les estás regalando la información que necesitan para pasar a la Creación del Gancho, diseñando un mensaje que parezca legítimo e inofensivo.",
        "Sin embargo, la fase más crítica es la Explotación. Es en este punto donde el ataque depende enteramente de ti. El atacante necesita que cometas un error. Si eres un perfil complaciente, impulsivo o ansioso, tu instinto te empujará a hacer clic. Esta es tu última línea de defensa. Aplicar una pausa de 10 segundos antes de actuar puede marcar la diferencia entre detener la amenaza o permitir que pase a la fase de Instalación, donde el virus (como un ransomware) cifra tus archivos, se propaga a otros dispositivos de la empresa y extrae contraseñas financieras.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 29
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 27",
      "title": "La Inteligencia Artificial como Arma (Parte I)",
      "visual_title": "La Nueva Era del Engaño: Phishing, Smishing y QRshing",
      "text_on_screen": [
        "• Phishing Contextual e Hiper-personalizado (Email): Los atacantes utilizan IA (Modelos de Lenguaje) para redactar correos sin errores gramaticales, imitando el tono exacto de tus superiores y citando proyectos reales extraídos de internet.",
        "• Smishing: Ataques a través de mensajes SMS que contienen enlaces maliciosos para robar información o instalar malware.",
        "• QRshing (El peligro físico): Uso de códigos QR falsos pegados sobre códigos legítimos en lugares comunes de la oficina (como cafeterías o folletos corporativos)."
      ],
      "extended_text": [
        "\"Hasta hace poco, la regla de oro para detectar un correo falso era buscar faltas de ortografía o traducciones robóticas. Con la llegada de la Inteligencia Artificial, esto ha desaparecido.",
        "Los atacantes utilizan IA para generar Phishing Contextual: correos que adoptan el tono exacto de tus superiores o proveedores, haciendo referencias a proyectos en los que estás trabajando. Aumentan drásticamente la credibilidad para ganar tu confianza. Pero el engaño ha salido de la bandeja de entrada.",
        "A través del Smishing, recibes SMS simulando ser tu banco o empresa de mensajería. Aún más insidioso es el QRshing en el propio entorno de la oficina. Los atacantes pueden colocar códigos QR maliciosos en la cafetería, simulando ser el menú o una encuesta interna de Recursos Humanos. Al escanearlo con tu móvil corporativo, te redirigen a webs peligrosas diseñadas para robar tus credenciales de acceso.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 30
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 28",
      "title": "La Anatomía del Engaño (Detectando el Phishing)",
      "visual_title": "Anatomía de un correo falso: Dónde mirar antes de hacer clic",
      "text_on_screen": [
        "El remitente real: Nunca confíes en el nombre visible. Comprueba siempre la dirección de correo exacta que hay detrás. Los atacantes registran dominios casi idénticos a los reales.",
        "El sentido de urgencia: Frases como \"actúa en 24 horas\", \"tu cuenta será bloqueada\" o \"factura impagada\" son tácticas psicológicas para anular tu capacidad de análisis.",
        "La prueba del enlace: Antes de hacer clic en cualquier botón o enlace, pasa el cursor del ratón por encima sin pulsar. El sistema te mostrará la dirección web real a la que te dirige. Si no coincide con la de la empresa, es un fraude."
      ],
      "extended_text": [
        "El segundo paso es desactivar la urgencia. Los cibercriminales saben que el estrés genera errores. Si un correo exige una acción inmediata bajo amenaza de bloqueo o sanción, aplica la pausa de los 10 segundos. Finalmente, utiliza la técnica de pasar el ratón. Al situar el cursor sobre un enlace o botón sin hacer clic, aparecerá un pequeño recuadro mostrando el destino real. Si el botón dice 'Ver factura de Microsoft' pero el destino es una página web desconocida, repórtalo inmediatamente.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 31
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 28",
      "title": "La Inteligencia Artificial como Arma (Parte III)",
      "visual_title": "Cuando tus ojos y oídos te engañan (Vishing y Deepfakes)",
      "text_on_screen": [
        "• Vishing (Fraude Telefónico con IA): Los atacantes clonan la voz de un directivo mediante Inteligencia Artificial para realizar solicitudes fraudulentas (ej. transferencias urgentes).",
        "• Deepfakes en Videollamadas: Replicar la imagen en movimiento de un directivo en tiempo real para aumentar la presión y la credibilidad de sus demandas.",
        "• El riesgo para la empresa es inmenso: La tecnología actual puede engañar a nuestros sentidos básicos."
      ],
      "extended_text": [
        "\"La evolución del fraude nos lleva al Vishing, una técnica donde ya no te escriben, sino que te llaman. Utilizando fragmentos de voz extraídos de vídeos corporativos o redes sociales, la IA puede clonar la voz de tu director general. Recibirás una llamada que suena exactamente igual que él, pidiendo acceso a un sistema o una transferencia urgente.",
        "El nivel extremo de esta amenaza son los Deepfakes. Un atacante puede infiltrarse en una reunión virtual (videollamada) con el rostro y la voz de un alto cargo, replicando sus movimientos faciales en tiempo real. Su objetivo es generar presión máxima para obligarte a saltarte los protocolos financieros o de seguridad. Ante esto, la única defensa no es la tecnología, sino el procedimiento: cualquier solicitud económica o de datos críticos que se salga de la norma debe ser verificada a través de un canal secundario e independiente.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 32
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 29",
      "title": "El Enemigo Silencioso en Casa y el AI Act",
      "visual_title": "Shadow AI y Alfabetización: El Riesgo de las IAs Públicas",
      "text_on_screen": [
        "• ¿Qué es la Shadow AI? El uso de herramientas de IA Generativa (como ChatGPT, Gemini o Claude) para tareas laborales sin la autorización ni supervisión de IT.",
        "• El Riesgo Operativo: Introducir datos confidenciales (planes estratégicos, datos de clientes, código fuente) en estas plataformas públicas para que nos \"ayuden\" a redactar o resumir.",
        "• Alfabetización en IA (AI Act): La normativa exige a los profesionales entender que la información enviada a una IA pública abandona el perímetro seguro de la empresa.",
        "• La Consecuencia: Los datos pueden quedar expuestos o ser utilizados para entrenar modelos futuros, suponiendo una violación gravísima del RGPD."
      ],
      "extended_text": [
        "\"Todos buscamos ser más productivos, y la Inteligencia Artificial ofrece atajos tentadores. Sin embargo, cuando utilizamos estas herramientas por nuestra cuenta, sin el aval del departamento técnico, caemos en lo que se denomina Shadow AI (IA en la sombra).",
        "Imagina que tomas un PDF que contiene el listado de nóminas, datos médicos de empleados o la estrategia de negocio de un cliente clave, y lo subes a una IA pública de internet pidiendo un resumen. En ese milisegundo, has sacado información altamente confidencial del perímetro seguro de la empresa y se la has entregado a los servidores de una empresa tecnológica externa.",
        "El nuevo Reglamento Europeo de Inteligencia Artificial (AI Act) obliga a las empresas a fomentar la 'Alfabetización en IA'. Esto significa que debes ser consciente de que los datos introducidos en plataformas gratuitas pueden ser utilizados para entrenar a sus modelos, exponiendo el secreto industrial y vulnerando frontalmente el RGPD.",
        "Nunca alimentes a una IA pública con datos privados de la corporación.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 33
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 31",
      "title": "Pregunta 1",
      "visual_title": "Quiz Módulo 2: Supera la Evaluación (Esta pantalla bloquea el avance del alumno en el LMS hasta que responda correctamente).",
      "text_on_screen": [
        "Pregunta 1: Recibes una videollamada de tu responsable directo pidiendo que hagas una transferencia urgente que \"no puede esperar\". La voz y la cara parecen reales, pero el proceso es inusual. ¿Qué haces?",
        "• [A] Realizo la transferencia de inmediato para evitar problemas.",
        "• [B] Cuelgo y contacto por un canal alternativo (teléfono personal o chat interno) para confirmar la identidad.",
        "• [C] Lo hago, pero pido un email de confirmación después."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 45,
      "question_text": "Recibes una videollamada de tu responsable directo pidiendo que hagas una transferencia urgente que \"no puede esperar\". La voz y la cara parecen reales, pero el proceso es inusual. ¿Qué haces?",
      "options": [
        {
          "id": "A",
          "text": "Realizo la transferencia de inmediato para evitar problemas."
        },
        {
          "id": "B",
          "text": "Cuelgo y contacto por un canal alternativo (teléfono personal o chat interno) para confirmar la identidad."
        },
        {
          "id": "C",
          "text": "Lo hago, pero pido un email de confirmación después."
        }
      ],
      "correct_answer": "B",
      "feedback": "Con la existencia de los Deepfakes, la vista y el oído ya no son suficientes para garantizar la identidad. Colgar y utilizar un canal de verificación independiente es la única forma de desarmar este ataque de ingeniería social. •",
      "id": 34
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 32",
      "title": "Pregunta 2",
      "visual_title": "Quiz Módulo 2: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 2: ¿Qué riesgo principal supone introducir un documento con datos de clientes en una IA generativa pública para resumirlo (Shadow AI)?",
        "• [A] Ninguno, la IA es privada.",
        "• [B] Una brecha de seguridad de datos (RGPD), ya que la información sale del control de la empresa y vulnera el principio de Alfabetización del AI Act.",
        "• [C] Que la IA haga un resumen incorrecto."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 45,
      "question_text": "¿Qué riesgo principal supone introducir un documento con datos de clientes en una IA generativa pública para resumirlo (Shadow AI)?",
      "options": [
        {
          "id": "A",
          "text": "Ninguno, la IA es privada."
        },
        {
          "id": "B",
          "text": "Una brecha de seguridad de datos (RGPD), ya que la información sale del control de la empresa y vulnera el principio de Alfabetización del AI Act."
        },
        {
          "id": "C",
          "text": "Que la IA haga un resumen incorrecto."
        }
      ],
      "correct_answer": "B",
      "feedback": "Al introducir datos en una IA pública (Shadow AI), la información pasa a los servidores de un tercero. Esto supone una exposición directa de la confidencialidad y una violación del Reglamento General de Protección de Datos (RGPD). •",
      "id": 35
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 33",
      "title": "Pregunta 3",
      "visual_title": "Quiz Módulo 2: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 3: En la Cyber Kill Chain, ¿cuál es el momento crítico en el que el trabajador puede detener el ataque?",
        "• [A] En la fase de reconocimiento del atacante.",
        "• [B] En la fase de explotación (antes de hacer clic o descargar el gancho).",
        "• [C] Una vez que el virus ya está instalado."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 45,
      "question_text": "En la Cyber Kill Chain, ¿cuál es el momento crítico en el que el trabajador puede detener el ataque?",
      "options": [
        {
          "id": "A",
          "text": "En la fase de reconocimiento del atacante."
        },
        {
          "id": "B",
          "text": "En la fase de explotación (antes de hacer clic o descargar el gancho)."
        },
        {
          "id": "C",
          "text": "Una vez que el virus ya está instalado."
        }
      ],
      "correct_answer": "B",
      "feedback": "No podemos evitar que nos investiguen o nos envíen correos engañosos, pero la fase de Explotación requiere nuestra participación. Aplicar una pausa consciente antes de actuar rompe la cadena del ciberataque y detiene la amenaza. •",
      "id": 36
    },
    {
      "module_id": 2,
      "module_title": "Psicología del Ataque y Shadow AI",
      "slide_num_str": "Diapositiva 34 - Pregunta 4",
      "title": "Pregunta 4",
      "visual_title": "Quiz Módulo 2: Supera la Evaluación",
      "type": "quiz_question",
      "time": 45,
      "question_text": "De acuerdo con el Reglamento de Inteligencia Artificial de la UE (AI Act), ¿qué implica el concepto de \"Alfabetización en IA\" para un empleado?",
      "options": [
        {
          "id": "A",
          "text": "Saber programar modelos de lenguaje desde cero."
        },
        {
          "id": "B",
          "text": "Comprender cómo usar la IA de forma ética y segura, siendo consciente de que los datos introducidos en IAs públicas pueden ser utilizados para entrenar modelos externos."
        },
        {
          "id": "C",
          "text": "Comprar una licencia premium de herramientas de IA generativa."
        }
      ],
      "extended_text": [],
      "image_desc": null,
      "correct_answer": "B",
      "feedback": "El AI Act dicta que los usuarios corporativos deben estar capacitados (Alfabetizados) para comprender las consecuencias legales y operativas de ceder datos empresariales a algoritmos de terceros no controlados. •",
      "id": 37
    },
    {
      "module_id": 2,
      "module_title": "Psicología del Ataque y Shadow AI",
      "slide_num_str": "Diapositiva 34 - Pregunta 5",
      "title": "Pregunta 5",
      "visual_title": "Quiz Módulo 2: Supera la Evaluación",
      "type": "quiz_question",
      "time": 45,
      "question_text": "Tras realizar el test OCEAN, descubres que tienes un Perfil C (Ansioso / Alto Neuroticismo). ¿A qué tipo de ataques basados en ingeniería social eres más vulnerable?",
      "options": [
        {
          "id": "A",
          "text": "A usar herramientas IA gratuitas por pura curiosidad tecnológica."
        },
        {
          "id": "B",
          "text": "A correos de \"Fraude del CEO\" o multas falsas que generan un pánico artificial y te empujan a saltarte los protocolos por miedo."
        },
        {
          "id": "C",
          "text": "A publicar fotos de tu escritorio en Instagram."
        }
      ],
      "extended_text": [],
      "image_desc": null,
      "correct_answer": "B",
      "feedback": "El modelo OCEAN demuestra que los atacantes abusan de la reactividad ante el estrés. Si tu perfil es ansioso, tu regla de oro es recordar que el protocolo de seguridad siempre está por encima de la jerarquía o el sentido de urgencia.",
      "id": 38
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 35",
      "title": "Resultados y Retroalimentación del Quiz",
      "visual_title": "Resultados del Módulo 2 Texto Principal (En pantalla):",
      "text_on_screen": [
        "• Respuesta Correcta Q1: [B] - ¿Por qué? Con la existencia de los Deepfakes, la vista y el oído ya no son suficientes para garantizar la identidad. Colgar y utilizar un canal de verificación independiente es la única forma de desarmar este ataque de ingeniería social.",
        "• Respuesta Correcta Q2: [B] - ¿Por qué? Al introducir datos en una IA pública (Shadow AI), la información pasa a los servidores de un tercero. Esto supone una exposición directa de la confidencialidad y una violación del Reglamento General de Protección de Datos (RGPD).",
        "• Respuesta Correcta Q3: [B] - ¿Por qué? No podemos evitar que nos investiguen o nos envíen correos engañosos, pero la fase de Explotación requiere nuestra participación. Aplicar una pausa consciente antes de actuar rompe la cadena del ciberataque y detiene la amenaza.",
        "• Respuesta Correcta Q4: [B] - ¿Por qué? El AI Act dicta que los usuarios corporativos deben estar capacitados (Alfabetizados) para comprender las consecuencias legales y operativas de ceder datos empresariales a algoritmos de terceros no controlados.",
        "• Respuesta Correcta Q5: [B] - ¿Por qué? El modelo OCEAN demuestra que los atacantes abusan de la reactividad ante el estrés. Si tu perfil es ansioso, tu regla de oro es recordar que el protocolo de seguridad siempre está por encima de la jerarquía o el sentido de urgencia."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_feedback",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 0,
      "id": 39
    },
    {
      "module_id": 2,
      "slide_num_str": "Diapositiva 36",
      "title": "Introducción a la Privacidad 360",
      "visual_title": "",
      "text_on_screen": [
        "• El dato personal se ha convertido en el activo digital más valioso y, en consecuencia, en el más regulado y protegido del mundo corporativo.",
        "• El Cambio de Paradigma: Los datos que manejamos en la oficina no pertenecen a nuestra empresa; son un préstamo temporal otorgado por el ciudadano bajo condiciones estrictas y auditables.",
        "• Tu Rol Legal: Al manejar información en tu puesto de trabajo, te conviertes de facto en un operador dentro de la cadena de \"Tratamiento de Datos\"."
      ],
      "extended_text": [
        "\"Entramos en el terreno de la privacidad y el cumplimiento normativo estricto. El Reglamento General de Protección de Datos (RGPD) europeo y la Ley Orgánica de Protección de Datos y Garantía de los Derechos Digitales (LOPDGDD) española no son meras recomendaciones corporativas; son escudos legales diseñados para proteger los derechos fundamentales de los ciudadanos.",
        "Durante décadas, las empresas operaron bajo la falsa creencia de que si recopilaban un dato, ese dato les pertenecía. La legislación actual ha destruido esa noción. Los datos son propiedad exclusiva de la persona física. Nosotros, como organización y como empleados, somos simples custodios temporales. Se nos ha otorgado permiso para gestionar esa información con un propósito muy específico (por ejemplo, facturar un servicio o enviar un pedido). Utilizar ese dato para cualquier otro fin sin consentimiento explícito no es una 'estrategia de negocio agresiva', es una infracción de la ley que acarrea responsabilidades civiles y penales.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Psicología del Ataque y Shadow AI",
      "time": 60,
      "id": 40
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 37",
      "title": "La Anatomía del Dato Personal",
      "visual_title": "¿Qué es exactamente un \"Dato Personal\"?",
      "text_on_screen": [
        "• Bajo el RGPD y la LOPDGDD, un dato personal abarca mucho más que un nombre o un número de cuenta.",
        "• Definición legal: Es cualquier información que permita identificar a una persona física, ya sea de forma directa o indirecta.",
        "• Ejemplos no evidentes: Una dirección IP, la matrícula de un vehículo, un historial de navegación web, un patrón de voz o una fotografía en un evento de empresa."
      ],
      "extended_text": [
        "\"Uno de los errores más comunes en la oficina es subestimar qué constituye un dato personal. Solemos pensar que si eliminamos el DNI o el Nombre de un documento Excel, la información ya es anónima y podemos compartirla libremente. Esto es falso. La ley define el dato personal como cualquier pieza de información que, cruzada con otras fuentes, permita aislar e identificar a un individuo concreto.",
        "Por ejemplo, un registro que solo contenga 'Código postal 43003, Mujer, Profesión: Investigadora en IA' puede ser suficiente para identificar a una persona específica en una población reducida. Para que un conjunto de datos deje de estar sujeto al RGPD, debe someterse a procesos matemáticos rigurosos de anonimización que garanticen que la reidentificación es imposible.",
        "Si no se han aplicado estas técnicas de control de divulgación estadística, el dato sigue siendo personal y debes tratarlo con el máximo rigor legal.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 41
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 38",
      "title": "Clasificación de Riesgo y Categorización del ENS",
      "visual_title": "Niveles de Riesgo del Dato: Datos Básicos y Nivel ENS",
      "text_on_screen": [
        "• La normativa exige aplicar medidas de seguridad que sean estrictamente proporcionales a la sensibilidad de la información manejada.",
        "• Datos Básicos (Riesgo Moderado): Incluyen información como nombre, apellidos, teléfono corporativo, correo electrónico o dirección profesional.",
        "• El Esquema Nacional de Seguridad (ENS): Si tratamos datos para la Administración Pública, estos datos se categorizan en niveles (Básico, Medio, Alto). Un nivel Básico exige trazabilidad de quién accede a ellos.",
        "• Medidas técnicas requeridas: Control de acceso estándar (usuario y contraseña) y supervisión regular."
      ],
      "extended_text": [
        "\"No todos los datos tienen el mismo peso legal, ni requieren la misma fricción de seguridad. Tratar toda la información de forma homogénea paralizaría las operaciones de la empresa. Los Datos Básicos componen el grueso del trabajo diario: el directorio de contactos, el listado de correos de proveedores o los números de teléfono de la oficina. Este tipo de información se considera de riesgo moderado. Su exposición generaría inconvenientes, pero rara vez destruiría la reputación o la vida personal del afectado.",
        "A esto debemos sumar el Esquema Nacional de Seguridad (ENS). Si nuestra empresa maneja estos datos en el marco de un contrato público, el ENS eleva la exigencia: debes garantizar que dejas un rastro auditable cada vez que consultas esta información. Aplicar las medidas estándar significa no dejar la base de datos abierta en tu pantalla cuando te vas a tomar un café, y asegurarte de que solo tienen acceso a esa carpeta los compañeros que realmente lo necesitan para su trabajo.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 42
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 39",
      "title": "Clasificación de Riesgo - Nivel Crítico",
      "visual_title": "Niveles de Riesgo del Dato: Categoría Especial",
      "text_on_screen": [
        "• Datos de Categoría Especial (Riesgo Crítico): Revelan información íntima que puede ser utilizada para discriminar o extorsionar al individuo.",
        "• Ejemplos: Datos de salud (bajas médicas), afiliación sindical, religión, origen racial, orientación sexual o datos biométricos (huella dactilar, reconocimiento facial).",
        "• Medidas técnicas requeridas: Cifrado obligatorio, auditoría de accesos y protocolos estrictos de manejo."
      ],
      "extended_text": [
        "\"Aquí es donde la ley traza una línea roja. Los Datos de Categoría Especial requieren un nivel de diligencia absoluto. Piensa en un justificante de baja médica que llega a Recursos Humanos, en la afiliación sindical de la plantilla, o en la huella dactilar que usamos para fichar en la entrada de la oficina. Una filtración de esta información tiene un impacto devastador: puede causar discriminación laboral, persecución social o daños psicológicos irreparables al ciudadano.",
        "Por esta razón, el RGPD prohíbe por norma general el tratamiento de estos datos, salvo excepciones muy tasadas. Si en tu puesto de trabajo manejas este tipo de información, debes saber que su almacenamiento exige cifrado obligatorio en reposo y en tránsito. Enviar un informe médico no cifrado por correo electrónico ordinario a un compañero de otro departamento constituye una grave.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 43
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 40",
      "title": "Clasificación de Riesgo - Alta Protección",
      "visual_title": "Niveles de Riesgo del Dato: Menores de Edad",
      "text_on_screen": [
        "• Datos de Menores (Alta Protección): La información relativa a menores de edad se considera intrínsecamente vulnerable.",
        "• Tratamiento condicionado: No deben ser tratados sin un protocolo específico autorizado y supervisado por el Delegado de Protección de Datos (DPO).",
        "• Regla corporativa: Restricción de acceso exclusivo al personal estrictamente autorizado."
      ],
      "extended_text": [
        "\"Los menores de edad gozan de una hiperprotección en el ordenamiento jurídico europeo. La ley asume que un menor no tiene la capacidad plena para comprender los riesgos, las consecuencias a largo plazo, ni las salvaguardas asociadas al tratamiento de su información digital. Los datos de menores siempre se consideran de alta protección.",
        "Si tu empresa organiza un evento familiar, gestiona seguros médicos que incluyen a los hijos de los empleados, o recopila imágenes en las que aparecen menores, se deben activar protocolos extraordinarios. Nadie en la organización debe recopilar, almacenar o difundir información de menores sin el aval explícito, escrito y documentado del Delegado de Protección de Datos (DPO) de la empresa.",
        "Estudio de Caso: La publicación en las redes sociales corporativas de una fotografía de una visita escolar a las instalaciones, sin el consentimiento expreso y verificado de cada uno de los tutores legales, ha derivado históricamente en sanciones fulminantes por parte de la AEPD.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 44
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 41",
      "title": "La Tríada de la Seguridad y el Canal de Denuncias",
      "visual_title": "Tus Deberes Legales (I): La Confidencialidad y la Ley 2/2023",
      "text_on_screen": [
        "• La seguridad de la información corporativa pivota sobre tres ejes: Confidencialidad, Integridad y Disponibilidad.",
        "1. El Deber de Confidencialidad: Garantizar que los datos no sean revelados ni accesibles a individuos, entidades o procesos no autorizados.",
        "• Perpetuidad Legal: Este deber no caduca al apagar el ordenador. Persiste de forma indefinida, incluso después de finalizar tu contrato laboral.",
        "• Reporte Obligatorio (Ley 2/2023): Si detectas que un compañero o superior vulnera la confidencialidad sistemáticamente, debes usar el Canal de Denuncias interno."
      ],
      "extended_text": [
        "\"El pilar más intuitivo de la protección de datos es la Confidencialidad. Como operador de información corporativa, asumes un deber de secreto profesional sobre todo lo que ves, lees o gestionas. Es vital comprender la naturaleza perpetua de este deber. La confidencialidad no termina a las seis de la tarde, ni se extingue cuando cambias de empresa.",
        "Si en el futuro revelas a un tercero el listado de clientes de tu antigua empresa, las condiciones de un contrato o los salarios de tus excompañeros, estarás cometiendo un delito, independientemente del tiempo que haya transcurrido.",
        "Además, bajo la Ley 2/2023 de Protección del Informante, eres parte activa de esta defensa. Si observas que en tu departamento se imprimen documentos de categoría especial y se tiran a la basura común rompiendo la confidencialidad, tienes el deber de notificarlo a través del Canal de Denuncias de la empresa, operando bajo un anonimato protegido que te exime de cualquier represalia.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 45
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 42",
      "title": "La Tríada de la Seguridad - Integridad",
      "visual_title": "Tus Deberes Legales (II): La Integridad del Dato",
      "text_on_screen": [
        "2. El Deber de Integridad: Proteger la información contra alteraciones, modificaciones o destrucciones no autorizadas (ya sean accidentales o intencionadas).",
        "• La prohibición del Shadow IT: Guardar datos de la empresa en dispositivos USB personales no cifrados o nubes privadas (Google Drive personal, Dropbox) destruye la integridad del sistema."
      ],
      "extended_text": [
        "\"La Integridad asegura que el dato que estamos consultando es exacto, completo y no ha sido alterado de forma fraudulenta o accidental. En el ámbito corporativo, una pérdida de integridad puede llevar a decisiones desastrosas: un número de cuenta alterado en una factura resultará en un pago a un ciberdelincuente; un grupo sanguíneo modificado por error en una base de datos médica puede ser fatal.",
        "¿Cómo rompen los empleados la integridad sin darse cuenta? A través de la comodidad. Cuando copias la base de datos oficial a un USB personal para 'avanzar trabajo en casa', o la subes a tu Dropbox privado, estás creando versiones no controladas del documento. Esto rompe la trazabilidad de la empresa y destruye la integridad de los datos, ya que el departamento de IT no puede garantizar quién ha modificado ese archivo aislado ni protegerlo de infecciones externas.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 46
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 43",
      "title": "La Tríada de la Seguridad - Disponibilidad",
      "visual_title": "Tus Deberes Legales (III): La Disponibilidad",
      "text_on_screen": [
        "3. El Deber de Disponibilidad: Asegurar que la información esté plenamente accesible y utilizable para las personas autorizadas en el momento en que la necesiten.",
        "• El secuestro de la Disponibilidad: Un ataque de Ransomware no suele robar los datos inicialmente; los cifra (los bloqueos) para extorsionar a la empresa paralizando su operatividad.",
        "• Perder una contraseña de acceso o borrar una carpeta departamental por error humano es una brecha legal de seguridad."
      ],
      "extended_text": [
        "\"La Disponibilidad es, a menudo, la gran olvidada en la protección de datos, pero es la responsable directa de la quiebra de muchas empresas tras un ciberataque. De nada sirve que nuestros datos sean confidenciales e íntegros si, cuando el negocio necesita facturar u operar, los archivos están inaccesibles.",
        "Los ataques modernos más temidos, como el Ransomware (secuestro de datos), atacan directamente a este pilar. Un empleado hace clic en un archivo malicioso y, silenciosamente, el virus encripta todo el disco duro y las carpetas compartidas de la red. La empresa no ha perdido la confidencialidad (nadie ha leído los datos), pero ha perdido la disponibilidad. La operativa se detiene en seco.",
        "Reflexión: Un fallo de disponibilidad también puede ser 100% humano. Si eres el único que conoce la contraseña de un archivo crítico de Excel y la olvidas, o si borras una carpeta compartida por accidente sin avisar para recuperar la copia de seguridad, estás provocando un incidente legal de disponibilidad que debe ser gestionado y reportado.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 47
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 44",
      "title": "Procesamiento Automatizado y el AI Act",
      "visual_title": "Tratamiento de Datos por Inteligencia Artificial (AI Act)",
      "text_on_screen": [
        "• Evaluaciones Automatizadas (Art. 22 RGPD y AI Act): Los ciudadanos tienen derecho a no ser objeto de una decisión basada únicamente en el tratamiento automatizado (incluida la elaboración de perfiles).",
        "• La Intervención Humana: Si la empresa utiliza IA para filtrar currículums, evaluar la concesión de créditos o analizar el rendimiento laboral, siempre debe existir supervisión humana significativa.",
        "• El Peligro Legal de la IA: Cargar información personal (PII) de ciudadanos europeos en sistemas de Inteligencia Artificial que no garanticen la explicabilidad de sus algoritmos vulnera los derechos fundamentales."
      ],
      "extended_text": [
        "\"La forma en que procesamos la información ha evolucionado. Con la entrada del Reglamento Europeo de Inteligencia Artificial (AI Act), se añade una capa crítica a la protección de datos personales.",
        "Hoy en día, las empresas utilizan IAs para procesar datos más rápido. Sin embargo, el artículo 22 del RGPD y el AI Act nos exigen garantizar un derecho fundamental: la supervisión humana. Si usas un sistema automatizado para decidir si se le otorga un crédito a un cliente o si se descarta un currículum en Recursos Humanos, el usuario tiene derecho a solicitar que un ser humano revise esa decisión y a que se le explique la lógica que ha seguido el algoritmo.",
        "Como operador de datos, nunca delegues decisiones que afecten jurídicamente a ciudadanos exclusivamente en una Inteligencia Artificial, y recuerda que cualquier herramienta de IA que alimentes con datos personales debe estar validada previamente por el DPO.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 48
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 45",
      "title": "El Empoderamiento Ciudadano (Derechos ARSOPOL)",
      "visual_title": "Los Derechos ARSOPOL: El Control del Ciudadano (Parte I)",
      "text_on_screen": [
        "• A - Acceso: El ciudadano tiene derecho a preguntar qué datos exactos tenemos sobre él y con qué fin los usamos.",
        "•R - Rectificación: Derecho a exigir que corrijamos datos inexactos, obsoletos o incompletos de forma gratuita y ágil.",
        "• S - Supresión (El Derecho al Olvido): Capacidad de solicitar la eliminación total de su rastro en nuestra organización."
      ],
      "extended_text": [
        "\"El RGPD ha empoderado al ciudadano. Los clientes ya no son sujetos pasivos; tienen herramientas legales (los derechos ARSOPOL) para exigir transparencia y control. Cualquier persona puede enviar un correo a la empresa ejerciendo su derecho de Acceso. La empresa está obligada por ley a entregarle una copia exacta y comprensible de toda la información que poseemos de él. Si el cliente detecta que su dirección es antigua o su perfil está mal categorizado, ejercerá la Rectificación, obligándonos a actualizar nuestras bases de datos.",
        "El derecho más conocido, y a la vez el más delicado, es la Supresión, popularizado como el 'Derecho al Olvido'. Permite al ciudadano exigir que lo borremos de nuestros sistemas. Sin embargo, su aplicación no es absoluta ni automática, como veremos a continuación.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 49
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 46",
      "title": "El Peligro Operativo del \"Derecho al Olvido\"",
      "visual_title": "La Trampa de la \"Supresión\" Eficiente",
      "text_on_screen": [
        "• El Escenario: Un cliente llama enfadado y exige: \"¡Quiero que borren mis datos inmediatamente de sus sistemas!\"",
        "• El Error: Como empleado eficiente, buscas su ficha en el CRM y le das a \"Eliminar registro\" para calmarlo.",
        "• La Realidad Legal: Has cometido una infracción grave. El derecho de supresión está limitado por las leyes de retención de datos."
      ],
      "extended_text": [
        "\"Analicemos un caso de la vida real. Un cliente contacta con Atención al Cliente y, amparándose en el RGPD, exige agresivamente que se eliminen todos sus datos y el historial de sus compras. Un empleado, con buena intención y para evitar una queja mayor, accede a la base de datos y borra la ficha del cliente.",
        "¿Cuál es el problema? Ese empleado acaba de destruir datos que la empresa estaba obligada a conservar por mandato legal. La ley tributaria (Hacienda) obliga a conservar los datos de facturación durante años, independientemente de lo que desee el cliente. La legislación laboral o de prevención de blanqueo de capitales imponen sus propios plazos de retención ineludibles.",
        "La regla estricta para cualquier empleado ante una petición de Supresión es nunca ejecutarla por cuenta propia. Toda solicitud ARSOPOL debe canalizarse inmediatamente hacia el Delegado de Protección de Datos (DPO) o el equipo Legal. Ellos evaluarán qué datos deben borrarse y cuáles deben bloquearse legalmente.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 50
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 47",
      "title": "Los Derechos ARSOPOL (Parte II)",
      "visual_title": "Los Derechos ARSOPOL: El Control del Ciudadano (Parte II)",
      "text_on_screen": [
        "• O - Oposición: Permite al ciudadano negarse a que usemos sus datos para fines específicos (por ejemplo, oponerse tajantemente a recibir marketing o publicidad directa).",
        "• PO - Portabilidad: El derecho a recibir sus datos en un formato digital estructurado (ej. un archivo CSV) para llevárselos fácilmente a la competencia.",
        "• L - Limitación: Solicitar la suspensión temporal del tratamiento de sus datos mientras se resuelve una disputa o revisión legal."
      ],
      "extended_text": [
        "\"Para completar el abanico de derechos ARSOPOL, encontramos la Oposición. Es muy habitual en campañas comerciales. Si un usuario se opone a recibir nuestro boletín de noticias, su dirección de correo debe ser introducida en una 'lista Robinson' interna. Seguir enviándole publicidad tras su oposición es motivo de sanción inmediata por parte de la AEPD.",
        "La Portabilidad fue diseñada para evitar los monopolios tecnológicos. Si un cliente decide irse a otra empresa, tiene derecho a pedirnos todo su historial para llevárselo. No podemos entregárselo en hojas impresas ilegibles; debemos proporcionarlo en un formato estructurado y digitalmente amigable.",
        "Por último, la Limitación actúa como una medida cautelar. Si un cliente demanda a la empresa alegando que sus datos son incorrectos, puede solicitar la Limitación. Durante el tiempo que dure la investigación, no podemos borrar los datos, pero tampoco podemos usarlos para operar; deben quedar 'congelados' en el sistema.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 51
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 49",
      "title": "Pregunta 1",
      "visual_title": "Quiz Módulo 3: Supera la Evaluación (Esta pantalla bloquea el avance del alumno en el LMS hasta que responda correctamente).",
      "text_on_screen": [
        "Pregunta 1: Según el RGPD y la LOPDGDD, ¿qué se considera legalmente un \"dato personal\"?",
        "• [A] Únicamente el nombre completo, el DNI y los datos de cuentas bancarias.",
        "• [B] Cualquier información que identifique o permita identificar a una persona física, incluyendo una dirección IP o una fotografía.",
        "• [C] Solo los datos médicos y la afiliación sindical de los empleados.",
        "• [D] Cualquier información corporativa o de balances financieros de una empresa competidora."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 45,
      "question_text": "Según el RGPD y la LOPDGDD, ¿qué se considera legalmente un \"dato personal\"?",
      "options": [
        {
          "id": "A",
          "text": "Únicamente el nombre completo, el DNI y los datos de cuentas bancarias."
        },
        {
          "id": "B",
          "text": "Cualquier información que identifique o permita identificar a una persona física, incluyendo una dirección IP o una fotografía."
        },
        {
          "id": "C",
          "text": "Solo los datos médicos y la afiliación sindical de los empleados."
        },
        {
          "id": "D",
          "text": "Cualquier información corporativa o de balances financieros de una empresa competidora."
        }
      ],
      "correct_answer": "B",
      "feedback": "El concepto legal de \"dato personal\" es increíblemente expansivo. Incluye cualquier traza digital o física que permita aislar la identidad de un sujeto, ya sea de forma directa o indirecta mediante cruce de bases de datos. •",
      "id": 52
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 50",
      "title": "Pregunta 2",
      "visual_title": "Quiz Módulo 3: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 2: Teniendo en cuenta la Tríada de la Seguridad, ¿cuándo finaliza tu deber legal de secreto y confidencialidad sobre los datos corporativos de clientes que has manejado?",
        "• [A] Cuando termina mi jornada laboral a las 18:00h.",
        "• [B] En el momento exacto en que finaliza o se extingue mi contrato de trabajo con la organización.",
        "• [C] Nunca. El deber de secreto y confidencialidad persiste de forma indefinida frente a la ley.",
        "• [D] A los 5 años, que es el plazo de prescripción de las leyes mercantiles."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 45,
      "question_text": "Teniendo en cuenta la Tríada de la Seguridad, ¿cuándo finaliza tu deber legal de secreto y confidencialidad sobre los datos corporativos de clientes que has manejado?",
      "options": [
        {
          "id": "A",
          "text": "Cuando termina mi jornada laboral a las 18:00h."
        },
        {
          "id": "B",
          "text": "En el momento exacto en que finaliza o se extingue mi contrato de trabajo con la organización."
        },
        {
          "id": "C",
          "text": "Nunca. El deber de secreto y confidencialidad persiste de forma indefinida frente a la ley."
        },
        {
          "id": "D",
          "text": "A los 5 años, que es el plazo de prescripción de las leyes mercantiles."
        }
      ],
      "correct_answer": "C",
      "feedback": "El deber de confidencialidad es de carácter perpetuo. El fin del contrato laboral no extingue la obligación de mantener en secreto la información sensible aprendida durante el desempeño del puesto. •",
      "id": 53
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 51",
      "title": "Pregunta 3",
      "visual_title": "Quiz Módulo 3: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 3: Un cliente te llama por teléfono muy enfadado y exige, ejerciendo sus derechos, que borres inmediatamente todos sus datos de la base de datos comercial de la empresa. ¿Cuál es el protocolo de actuación correcto?",
        "• [A] Buscar su ficha en el sistema y eliminarla en el acto para ser eficiente, calmar al cliente y cumplir el RGPD rápidamente.",
        "• [B] Informarle de que el RGPD no aplica a bases de datos comerciales y colgar la llamada.",
        "• [C] Informar de inmediato al Responsable de Seguridad o al DPO para que gestionen el derecho de supresión, evaluando los plazos de retención legal.",
        "• [D] Bloquear su número de teléfono en la centralita de la empresa."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 45,
      "question_text": "Un cliente te llama por teléfono muy enfadado y exige, ejerciendo sus derechos, que borres inmediatamente todos sus datos de la base de datos comercial de la empresa. ¿Cuál es el protocolo de actuación correcto?",
      "options": [
        {
          "id": "A",
          "text": "Buscar su ficha en el sistema y eliminarla en el acto para ser eficiente, calmar al cliente y cumplir el RGPD rápidamente."
        },
        {
          "id": "B",
          "text": "Informarle de que el RGPD no aplica a bases de datos comerciales y colgar la llamada."
        },
        {
          "id": "C",
          "text": "Informar de inmediato al Responsable de Seguridad o al DPO para que gestionen el derecho de supresión, evaluando los plazos de retención legal."
        },
        {
          "id": "D",
          "text": "Bloquear su número de teléfono en la centralita de la empresa."
        }
      ],
      "correct_answer": "C",
      "feedback": "El ciudadano está ejerciendo su derecho de Supresión (Derecho al Olvido) perteneciente a las siglas ARSOPOL. Un empleado jamás debe borrar registros unilateralmente, ya que la empresa puede tener obligaciones fiscales o legales que exijan la conservación bloqueada de esos datos. El DPO es quien debe auditar y ejecutar la petición. •",
      "id": 54
    },
    {
      "module_id": 3,
      "module_title": "Protección de Datos 360",
      "slide_num_str": "Diapositiva 52 - Pregunta 4",
      "title": "Pregunta 4",
      "visual_title": "Quiz Módulo 3: Supera la Evaluación",
      "type": "quiz_question",
      "time": 45,
      "question_text": "Tu empresa decide implementar un nuevo algoritmo de Inteligencia Artificial para filtrar automáticamente los currículums de los candidatos y descartar a los no aptos sin intervención humana. Según el AI Act y el RGPD, ¿es esto correcto?",
      "options": [
        {
          "id": "A",
          "text": "Sí, siempre y cuando la IA sea de una marca conocida."
        },
        {
          "id": "B",
          "text": "No, los ciudadanos tienen derecho a no ser objeto de decisiones basadas únicamente en el tratamiento automatizado sin una supervisión humana significativa."
        },
        {
          "id": "C",
          "text": "Sí, porque los currículums no contienen datos de Categoría Especial."
        }
      ],
      "extended_text": [],
      "image_desc": null,
      "correct_answer": "B",
      "feedback": "Delegar decisiones con impacto legal o vital íntegramente a una máquina atenta contra los derechos garantizados en el marco regulatorio europeo (AI Act y Art. 22 del RGPD). La supervisión y la explicabilidad humana son obligatorias. •",
      "id": 55
    },
    {
      "module_id": 3,
      "module_title": "Protección de Datos 360",
      "slide_num_str": "Diapositiva 52 - Pregunta 5",
      "title": "Pregunta 5",
      "visual_title": "Quiz Módulo 3: Supera la Evaluación",
      "type": "quiz_question",
      "time": 45,
      "question_text": "Trabajas para una empresa que gestiona datos de la Administración Pública. Observas reiteradamente que un directivo descarga bases de datos del nivel \"Básico\" (del ENS) a su USB personal para trabajar en casa sin dejar rastro de auditoría ni encriptarlo. ¿Qué debes hacer?",
      "options": [
        {
          "id": "A",
          "text": "Nada, es mi superior y yo no soy responsable de sus acciones."
        },
        {
          "id": "B",
          "text": "Utilizar el Canal de Denuncias interno (Ley 2/2023) para reportar esta infracción de los protocolos del Esquema Nacional de Seguridad y de la integridad/confidencialidad de los datos."
        },
        {
          "id": "C",
          "text": "Copiar mi propio trabajo a un USB también para ser más eficiente."
        }
      ],
      "extended_text": [],
      "image_desc": null,
      "correct_answer": "B",
      "feedback": "La extracción incontrolada (Shadow IT) destruye la Integridad y Confidencialidad de los datos. Bajo el ENS y la Ley 2/2023, reportar de forma segura la vulneración de los protocolos por parte de cualquier miembro de la empresa es un mecanismo legal protegido de responsabilidad proactiva. \"Felicidades por completar el Módulo 3. Has asimilado la carga teórica y legal más densa de todo el programa de Prevención de Riesgos Digitales. Comprender la naturaleza del dato, su nivel de riesgo y los derechos inalienables del ciudadano te convierte en un operador seguro y diligente. Con las bases legales blindadas, en el próximo módulo trasladaremos todos estos conocimientos al entorno físico y doméstico, abordando los grandes riesgos que supone el Teletrabajo y el trabajo en modelo híbrido.\"",
      "id": 56
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 53",
      "title": "Resultados y Feedback del Módulo 3",
      "visual_title": "Corrección y Retroalimentación: Módulo 3",
      "text_on_screen": [
        "• Q1: Correcta [B] - Feedback: El concepto legal de \"dato personal\" es increíblemente expansivo. Incluye cualquier traza digital o física que permita aislar la identidad de un sujeto, ya sea de forma directa o indirecta mediante cruce de bases de datos.",
        "• Q2: Correcta [C] - Feedback: El deber de confidencialidad es de carácter perpetuo. El fin del contrato laboral no extingue la obligación de mantener en secreto la información sensible aprendida durante el desempeño del puesto.",
        "• Q3: Correcta [C] - Feedback: El ciudadano está ejerciendo su derecho de Supresión (Derecho al Olvido) perteneciente a las siglas ARSOPOL. Un empleado jamás debe borrar registros unilateralmente, ya que la empresa puede tener obligaciones fiscales o legales que exijan la conservación bloqueada de esos datos. El DPO es quien debe auditar y ejecutar la petición.",
        "• Q4: Correcta [B] - Feedback: Delegar decisiones con impacto legal o vital íntegramente a una máquina atenta contra los derechos garantizados en el marco regulatorio europeo (AI Act y Art. 22 del RGPD). La supervisión y la explicabilidad humana son obligatorias.",
        "• Q5: Correcta [B] - Feedback: La extracción incontrolada (Shadow IT) destruye la Integridad y Confidencialidad de los datos. Bajo el ENS y la Ley 2/2023, reportar de forma segura la vulneración de los protocolos por parte de cualquier miembro de la empresa es un mecanismo legal protegido de responsabilidad proactiva."
      ],
      "extended_text": [
        "\"Felicidades por completar el Módulo 3. Has asimilado la carga teórica y legal más densa de todo el programa de Prevención de Riesgos Digitales. Comprender la naturaleza del dato, su nivel de riesgo y los derechos inalienables del ciudadano te convierte en un operador seguro y diligente. Con las bases legales blindadas, en el próximo módulo trasladaremos todos estos conocimientos al entorno físico y doméstico, abordando los grandes riesgos que supone el Teletrabajo y el trabajo en modelo híbrido.\""
      ],
      "image_desc": null,
      "type": "quiz_feedback",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 0,
      "id": 57
    },
    {
      "module_id": 3,
      "slide_num_str": "Diapositiva 54",
      "title": "El Perímetro ha Desaparecido (Teletrabajo)",
      "visual_title": "",
      "text_on_screen": [
        "• El fin del perímetro tradicional: Tu responsabilidad de proteger los datos viaja contigo a cualquier lugar desde donde te conectes.",
        "• Marco Legal (Ley 10/2021 de Trabajo a Distancia): Establece que es deber ineludible del trabajador seguir las instrucciones de seguridad informática de la empresa, incluso fuera de las instalaciones corporativas.",
        "• El Riesgo de Proximidad: Evitar el acceso accidental de familiares, visitas o extraños (en entornos públicos) a la información confidencial de la organización.",
        "• Esquema Nacional de Seguridad (ENS): Si tratas datos del sector público, el teletrabajo está sometido a estrictos controles de acceso remoto; usar equipos compartidos con la familia está totalmente prohibido."
      ],
      "extended_text": [
        "\"Hace apenas unos años, la seguridad de la empresa terminaba en la puerta de la oficina. Estábamos protegidos por firewalls corporativos, redes cerradas y un control de acceso físico. Hoy, con la consolidación del modelo híbrido y el teletrabajo, el perímetro de seguridad ha desaparecido por completo. Tu oficina es ahora la mesa de tu salón, una habitación de hotel, una cafetería o la bandeja de un tren.",
        "Desde el punto de vista del Compliance, la Ley 10/2021 de Trabajo a Distancia es taxativa: trabajar desde casa no relaja en absoluto tus obligaciones de seguridad. Las políticas corporativas te aplican con la misma rigidez. Cuando operamos en remoto, nos enfrentamos a un nuevo vector de ataque que llamamos 'riesgo de proximidad'. Además, si operamos bajo el Esquema Nacional de Seguridad (ENS), se nos exige garantizar que el equipo (\"endpoint\") no es accesible por terceros.",
        "Estudio de Caso Real: Un cargo intermedio, teletrabajando desde su domicilio, dejó su portátil abierto y sin bloquear en la mesa del comedor para atender al repartidor. Su hijo pequeño, jugando con el ratón, arrastró una carpeta con datos financieros a una nube pública que estaba sincronizada en el navegador. La empresa sufrió una brecha de datos (sancionable por la AEPD) no por la acción de un sofisticado hacker ruso, sino por una falta de control del entorno físico del empleado. Proteger el equipo de nuestro propio entorno familiar no es una falta de confianza, es una obligación legal.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protección de Datos 360",
      "time": 60,
      "id": 58
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 55",
      "title": "Política de Mesa Limpia y Pantalla Bloqueada",
      "visual_title": "La Barrera Física: Política de Mesa Limpia",
      "text_on_screen": [
        "La seguridad técnica es inútil si fallamos en el entorno físico. Este es un control auditable exigido por los estándares internacionales (ISO 27001):",
        "• Bloqueo Inmediato (Win+L): Bloquea siempre tu equipo antes de levantarte, aunque sea por unos segundos.",
        "• Cero Papeles Sensibles (Sin papeles): Prohibido dejar documentos con datos de clientes o contraseñas anotadas sobre la mesa al finalizar la jornada.",
        "• Destrucción Segura: Cualquier papel con información confidencial debe ser destruido en una máquina certificada, nunca arrojado a la papelera común."
      ],
      "extended_text": [
        "\"La ingeniería social y el espionaje corporativo también ocurren en el mundo físico. Si un técnico de mantenimiento, personal de limpieza, o una visita comercial pasa por tu escritorio, la información que vea en tu pantalla o en tus papeles impresos puede ser utilizada en contra de la empresa.",
        "La Política de Mesa Limpia y Pantalla Bloqueada no es una sugerencia de orden o estética impulsada por Recursos Humanos; es un control de seguridad auditable que los inspectores de la norma ISO 27001 verifican presencialmente. A nivel práctico, debes convertir en un acto reflejo el uso del atajo de teclado Windows + L (o Control + Command + Q en Mac) cada vez que tu cuerpo se separe de la silla. Asimismo, la gestión del papel es crítica. Imprimir un listado de clientes y tirarlo a la papelera normal tras usarlo es una vulneración directa del RGPD, ya que cualquier persona podría recuperarlo. Todo documento sensible debe ser procesado por una destructora de papel homologada.",
        "Ejercicio de Reflexión: Observa tu entorno de trabajo en este momento. Si alguien tomara una fotografía de tu mesa ahora mismo, ¿podría leer alguna contraseña, nombre de cliente o documento interno?. Si la respuesta es afirmativa, tienes una vulnerabilidad crítica que debes corregir de inmediato.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 60,
      "id": 59
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 56",
      "title": "Higiene en Redes Domésticas (El Router y la VPN)",
      "visual_title": "Blindando tu Hogar: El Túnel Seguro y el Router (Higiene en Redes Domésticas)",
      "text_on_screen": [
        "• El Túnel Seguro (VPN): Herramienta obligatoria para el teletrabajo. Cifra toda la información entre tu equipo remoto y los servidores de la empresa para evitar intercepciones.",
        "• Seguridad del Router: Tu router doméstico es la primera línea de defensa.",
        "Cambiar la contraseña de administración que viene por defecto.",
        "Asegurar que la red Wi-Fi utilice un protocolo de cifrado robusto (WPA3 o mínimo WPA2).",
        "Canal de Denuncias: Desactivar la VPN corporativa para \"navegar más rápido\" viola los protocolos de ciberseguridad."
      ],
      "extended_text": [
        "\"Cuando trabajas conectado al Wi-Fi de tu casa o al de una cafetería, tus datos corporativos viajan por infraestructuras que la empresa no controla. Si no tomas medidas, un atacante conectado a esa misma red podría interceptar fácilmente tus contraseñas y documentos mediante técnicas de Man-in-the-Middle (Hombre en el medio).",
        "Por esta razón, el uso de la VPN (Virtual Private Network) es innegociable. La VPN crea un 'túnel blindado y cifrado' que asegura que la información entre tu hogar y la empresa viaje de forma segura, volviéndose invisible para el proveedor de internet o para espías en la misma red. El Esquema Nacional de Seguridad (ENS) prohíbe explícitamente acceder a información de la Administración sin este túnel cifrado. Sin embargo, la VPN no te protege si el atacante ya ha comprometido tu propia red doméstica.",
        "Tu Router es tu verdadera frontera. Mantener la contraseña de administración que viene pegada de fábrica en el reverso del aparato es un riesgo extremo, ya que esas contraseñas suelen ser predecibles o estar filtradas en foros de hacking. Debes acceder a la configuración de tu router, cambiar la contraseña de administrador y asegurarte de que el cifrado de tu Wi-Fi es WPA2 o WPA3. Las redes abiertas o con cifrados antiguos (como WEP) pueden ser hackeadas en cuestión de minutos.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 60,
      "id": 60
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 57",
      "title": "El Riesgo Silencioso del Internet de las Cosas (IoT)",
      "visual_title": "El Peligro del IoT (Internet of Things) y Asistentes de Voz",
      "text_on_screen": [
        "• ¿Qué es el IoT? Bombillas inteligentes, aspiradoras, altavoces (Alexa, Echo) o cámaras de vigilancia conectadas a internet.",
        "• La Vulnerabilidad: Estos dispositivos económicos suelen tener medidas de seguridad muy limitadas o nulas, convirtiéndose en el eslabón más débil de tu red.",
        "• El Riesgo de Escucha (IA): Los altavoces inteligentes procesan el audio ambiental. Si tienes reuniones confidenciales en casa, estos dispositivos pueden registrar datos sensibles.",
        "• El Aislamiento (Mejor Práctica): Nunca conectes el PC del trabajo a la misma subred Wi-Fi que estos dispositivos. Crea una \"Red de Invitados\" en tu router para aislarlos."
      ],
      "extended_text": [
        "\"Nuestros hogares están cada vez más digitalizados. Hoy en día conectamos al Wi-Fi bombillas, enchufes, termostatos y cámaras de vigilancia baratas compradas por internet. Esto es lo que se conoce como el Internet de las Cosas (IoT). El gran problema del IoT es que los fabricantes priorizan la facilidad de uso y el bajo coste por encima de la seguridad. Estos dispositivos rara vez reciben actualizaciones y suelen tener contraseñas integradas que no se pueden cambiar. Se convierten en el punto de entrada perfecto para un cibercriminal.",
        "La técnica del salto: Si un hacker logra tomar el control de tu bombilla inteligente vulnerable, puede utilizarla como 'puente' o cabeza de puente para escanear tu red doméstica y saltar al ordenador de tu empresa, si ambos comparten la misma red Wi-Fi. Además, en la era de la Inteligencia Artificial (AI Act), los asistentes de voz suponen un riesgo directo a la confidencialidad. Estos dispositivos \"despiertan\" y graban fragmentos de audio para mejorar sus modelos. Si estás en una videollamada discutiendo datos de pacientes o estrategias comerciales, esa información confidencial puede terminar en los servidores de una empresa tecnológica externa.",
        "Para proteger la información de tu organización, debes aislar los entornos. Accede a tu router y crea una 'Red de Invitados' secundaria. Conecta allí todos los aparatos del hogar (IoT, consolas, tablets personales) y deja la red principal exclusivamente para tu ordenador corporativo y dispositivos de confianza. Esta segmentación minimiza drásticamente el riesgo.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 60,
      "id": 61
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 58",
      "title": "Actualizaciones y la Cyber Resilience Act (CRA)",
      "visual_title": "Mantenimiento y Parches: Cerrando la Puerta",
      "text_on_screen": [
        "• El Parche de Seguridad: Las actualizaciones no son para cambiar el diseño; corrigen vulnerabilidades críticas descubiertas recientemente. Retrasarlas es dejar la puerta abierta.",
        "• Software Original y la CRA: La Ley Europea de Ciberresiliencia (Cyber Resilience Act) exige el uso de productos 'seguros por diseño'.",
        "• Prohibición de Piratería: Instalar software pirata en equipos corporativos (o usarlo para trabajar) anula garantías legales y expone a la empresa a inyecciones de código malicioso."
      ],
      "extended_text": [
        "\"Una de las fricciones más comunes entre los usuarios y los departamentos técnicos es la insistencia en las actualizaciones de sistema. A menudo, cerramos la ventana emergente que nos pide reiniciar el equipo porque 'estamos muy ocupados' o no queremos interrumpir nuestro flujo de trabajo. Debemos cambiar esta mentalidad. Las actualizaciones de sistema no añaden simplemente 'nuevos colores' o funciones menores; en el 90% de los casos, contienen Parches de Seguridad. Estos parches son fragmentos de código diseñados para tapar un agujero crítico (una vulnerabilidad) que los hackers acaban de descubrir. Retrasar una actualización importante equivale a saber que la cerradura de tu casa está rota y decidir que ya la arreglarás la semana que viene.",
        "Asimismo, el marco legal europeo, a través de la Cyber Resilience Act (CRA), eleva los estándares exigiendo que el software comercial sea 'seguro por diseño'. Utilizar licencias falsas (software pirata) en el entorno laboral no solo es un delito contra la propiedad intelectual, sino que destruye esta capa de seguridad. Los programas piratas están manipulados para evadir los controles de licencia y, casi siempre, incluyen troyanos ocultos (puertas traseras) listos para comprometer la red corporativa.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 60,
      "id": 62
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 59",
      "title": "Falsa Productividad, \"Shadow IT\" y la IA Doméstica",
      "visual_title": "Shadow IT: El Riesgo de ir por Libre en Casa",
      "text_on_screen": [
        "• Definición de Shadow IT: Uso de aplicaciones, dispositivos o servicios en la nube no autorizados explícitamente por el departamento de IT para realizar tareas laborales.",
        "• Ejemplos Comunes en Teletrabajo: Usar conversores de PDF gratuitos online, cuentas personales de Dropbox/Google Drive, o gestores de tareas no corporativos.",
        "• El Peligro Legal: Al subir un documento corporativo a un servicio externo no auditado, se violan las políticas de seguridad y se pierde la trazabilidad del dato, generando una brecha de seguridad."
      ],
      "extended_text": [
        "\"Finalmente, en el entorno híbrido, surge un fenómeno impulsado por las buenas intenciones pero con consecuencias catastróficas: el Shadow IT (IT en la Sombra). Ocurre cuando un empleado, buscando ser más eficiente o resolver un problema rápido, decide utilizar herramientas tecnológicas sin pedir permiso al departamento de informática. Trabajando desde casa, la tentación se multiplica. Imagina que necesitas unir dos archivos PDF y, como no tienes el software oficial de pago, buscas en Google 'Unir PDF gratis' y subes el contrato confidencial de un cliente a una web desconocida. O que utilizas una IA generativa instalada en tu ordenador personal para redactar un informe corporativo, contraviniendo el AI Act sobre el procesamiento seguro de información. Acabas de regalar información sensible a un servidor que la empresa no controla. Has perdido la trazabilidad del documento y has violado el RGPD y el ENS (si son datos públicos).",
        "El Shadow IT genera puntos ciegos masivos para los equipos de seguridad, ya que no pueden proteger los datos si no saben en qué servidores externos los están alojando los propios empleados. El uso de herramientas aprobadas no es burocracia, es supervivencia.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 60,
      "id": 63
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 60",
      "title": "El perímetro de bolsillo (Móvil personal o BYOD)",
      "visual_title": "El Móvil Personal: Separando la vida privada de los datos corporativos",
      "text_on_screen": [
        "El riesgo de llevar la oficina en el bolsillo: Si configuras el correo corporativo o aplicaciones de la empresa en tu teléfono personal, este dispositivo se convierte en un activo auditable.",
        "Medidas obligatorias de protección: Es imprescindible contar con un PIN de bloqueo robusto o bloqueo biométrico (huella o rostro). Nunca dejes el móvil sin código.",
        "Protocolo de pérdida: Si pierdes un dispositivo personal que contiene información de la empresa, debes reportarlo al departamento técnico como un incidente de seguridad grave de forma inmediata."
      ],
      "extended_text": [
        "Si decides vincular tu teléfono a las herramientas del trabajo, adquieres automáticamente obligaciones de seguridad. La más básica e innegociable es el bloqueo del terminal. Llevar el teléfono en el bolsillo sin un PIN o un bloqueo biométrico expone toda la base de datos de la empresa si lo olvidas en un transporte público. Además, en caso de pérdida o robo del dispositivo personal, debes notificarlo al instante. La empresa tiene la capacidad legal y técnica de borrar los datos corporativos a distancia para proteger la información, pero solo si tienen constancia del incidente a tiempo.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 60,
      "id": 64
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 61",
      "title": "Pregunta 1",
      "visual_title": "Quiz Módulo 4: Supera la Evaluación (Esta pantalla bloquea el avance del alumno en el LMS hasta que responda correctamente).",
      "text_on_screen": [
        "Pregunta 1: Estás teletrabajando en una cafetería y necesitas ir al baño un momento. Teniendo en cuenta la política de seguridad y de mesa limpia, ¿qué debes hacer con tu portátil?",
        "• [A] Pedirle al de la mesa de al lado que lo vigile un momento.",
        "• [B] Dejarlo encendido pero tapar la cámara web con una pegatina.",
        "• [C] Bloquear la sesión (Ej. Win+L) y, si es posible, llevártelo contigo o asegurarlo físicamente.",
        "• [D] Apagarlo desenchufando la batería directamente."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 45,
      "question_text": "Estás teletrabajando en una cafetería y necesitas ir al baño un momento. Teniendo en cuenta la política de seguridad y de mesa limpia, ¿qué debes hacer con tu portátil?",
      "options": [
        {
          "id": "A",
          "text": "Pedirle al de la mesa de al lado que lo vigile un momento."
        },
        {
          "id": "B",
          "text": "Dejarlo encendido pero tapar la cámara web con una pegatina."
        },
        {
          "id": "C",
          "text": "Bloquear la sesión (Ej. Win+L) y, si es posible, llevártelo contigo o asegurarlo físicamente."
        },
        {
          "id": "D",
          "text": "Apagarlo desenchufando la batería directamente."
        }
      ],
      "correct_answer": "C",
      "feedback": "La política de mesa limpia y pantalla bloqueada es obligatoria en cualquier entorno. Un equipo desbloqueado en un lugar público es una brecha de seguridad crítica en potencia. El atajo de bloqueo rápido (Win+L) debe ser un acto reflejo. •",
      "id": 65
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 62",
      "title": "Pregunta 2",
      "visual_title": "Quiz Módulo 4: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 2: ¿Cuál es la función principal y crítica de utilizar una VPN (Túnel Seguro) cuando trabajas fuera de la oficina?",
        "• [A] Lograr que la conexión a internet sea mucho más rápida para videollamadas.",
        "• [B] Crear un túnel de conexión cifrado y seguro entre tu equipo y la red de la empresa, evitando que los datos sean interceptados.",
        "• [C] Permitir ver contenido de plataformas de streaming de otros países.",
        "• [D] Evitar tener que instalar las actualizaciones de Windows."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 45,
      "question_text": "¿Cuál es la función principal y crítica de utilizar una VPN (Túnel Seguro) cuando trabajas fuera de la oficina?",
      "options": [
        {
          "id": "A",
          "text": "Lograr que la conexión a internet sea mucho más rápida para videollamadas."
        },
        {
          "id": "B",
          "text": "Crear un túnel de conexión cifrado y seguro entre tu equipo y la red de la empresa, evitando que los datos sean interceptados."
        },
        {
          "id": "C",
          "text": "Permitir ver contenido de plataformas de streaming de otros países."
        },
        {
          "id": "D",
          "text": "Evitar tener que instalar las actualizaciones de Windows."
        }
      ],
      "correct_answer": "B",
      "feedback": "La VPN no mejora la velocidad, sino la seguridad. Su función es cifrar los datos que viajan por redes no seguras (como el Wi-Fi de tu casa o el de un hotel), impidiendo que ciberdelincuentes puedan leer o manipular la información corporativa en tránsito. •",
      "id": 66
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 63",
      "title": "Pregunta 3",
      "visual_title": "Quiz Módulo 4: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 3: ¿Qué significa el término \"Shadow IT\" en el entorno de la seguridad corporativa y el teletrabajo?",
        "• [A] Trabajar de noche o en entornos con poca luz para evitar reflejos en la pantalla.",
        "• [B] Un tipo de ciberataque de ransomware que oscurece la pantalla del ordenador.",
        "• [C] Usar aplicaciones, nubes o servicios de terceros (incluidas IAs públicas) no autorizados por la empresa para realizar tareas laborales.",
        "• [D] El departamento de informática que trabaja en turno de guardia."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 45,
      "question_text": "¿Qué significa el término \"Shadow IT\" en el entorno de la seguridad corporativa y el teletrabajo?",
      "options": [
        {
          "id": "A",
          "text": "Trabajar de noche o en entornos con poca luz para evitar reflejos en la pantalla."
        },
        {
          "id": "B",
          "text": "Un tipo de ciberataque de ransomware que oscurece la pantalla del ordenador."
        },
        {
          "id": "C",
          "text": "Usar aplicaciones, nubes o servicios de terceros (incluidas IAs públicas) no autorizados por la empresa para realizar tareas laborales."
        },
        {
          "id": "D",
          "text": "El departamento de informática que trabaja en turno de guardia."
        }
      ],
      "correct_answer": "C",
      "feedback": "El Shadow IT ocurre cuando los empleados utilizan software no auditado (como conversores de archivos online o IAs gratuitas) para trabajar. Esto destruye la trazabilidad de los datos y viola flagrantemente el RGPD y las políticas de la empresa. •",
      "id": 67
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 64",
      "title": "Pregunta 4",
      "visual_title": "Quiz Módulo 4: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 4: En el marco del Esquema Nacional de Seguridad (ENS) y las políticas de teletrabajo, ¿qué implica el \"riesgo de proximidad\" respecto a tu familia y tu equipo de trabajo corporativo?",
        "• [A] Que el equipo debe compartirse con los hijos para fines educativos.",
        "• [B] Que debes evitar de forma estricta el acceso accidental o el uso del equipo corporativo por parte de familiares, ya que la responsabilidad legal de proteger el entorno físico viaja contigo al domicilio.",
        "• [C] Que la empresa debe comprar un ordenador para cada miembro de tu familia."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 45,
      "question_text": "En el marco del Esquema Nacional de Seguridad (ENS) y las políticas de teletrabajo, ¿qué implica el \"riesgo de proximidad\" respecto a tu familia y tu equipo de trabajo corporativo?",
      "options": [
        {
          "id": "A",
          "text": "Que el equipo debe compartirse con los hijos para fines educativos."
        },
        {
          "id": "B",
          "text": "Que debes evitar de forma estricta el acceso accidental o el uso del equipo corporativo por parte de familiares, ya que la responsabilidad legal de proteger el entorno físico viaja contigo al domicilio."
        },
        {
          "id": "C",
          "text": "Que la empresa debe comprar un ordenador para cada miembro de tu familia."
        }
      ],
      "correct_answer": "B",
      "feedback": "La Ley de Trabajo a Distancia y el ENS son claros. El equipo es de uso exclusivamente profesional y personal; permitir que familiares o visitas interactúen con el equipo o visualicen la pantalla expone a la organización a severas brechas por negligencia humana. •",
      "id": 68
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 65",
      "title": "Pregunta 5",
      "visual_title": "Quiz Módulo 4: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 5: Tienes varios dispositivos inteligentes en casa (IoT) como bombillas Wi-Fi, termostatos y un altavoz con asistente de voz en el salón donde sueles tener videollamadas corporativas. ¿Cuál es la mejor práctica de ciberhigiene para proteger la información de tu empresa?",
        "• [A] Apagar el ordenador corporativo cada vez que se encienda la bombilla.",
        "• [B] Nunca conectar el ordenador del trabajo a la misma subred Wi-Fi que el IoT, creando una \"Red de Invitados\" aislada, y evitar discutir datos sensibles frente a asistentes de voz.",
        "• [C] Dejar los micrófonos de los asistentes de voz siempre encendidos para que resuman la reunión."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 45,
      "question_text": "Tienes varios dispositivos inteligentes en casa (IoT) como bombillas Wi-Fi, termostatos y un altavoz con asistente de voz en el salón donde sueles tener videollamadas corporativas. ¿Cuál es la mejor práctica de ciberhigiene para proteger la información de tu empresa?",
      "options": [
        {
          "id": "A",
          "text": "Apagar el ordenador corporativo cada vez que se encienda la bombilla."
        },
        {
          "id": "B",
          "text": "Nunca conectar el ordenador del trabajo a la misma subred Wi-Fi que el IoT, creando una \"Red de Invitados\" aislada, y evitar discutir datos sensibles frente a asistentes de voz."
        },
        {
          "id": "C",
          "text": "Dejar los micrófonos de los asistentes de voz siempre encendidos para que resuman la reunión."
        }
      ],
      "correct_answer": "B",
      "feedback": "Los dispositivos IoT (Internet of Things) suelen tener medidas de seguridad casi nulas y los asistentes de voz graban audio ambiental. Aislar el equipo corporativo de estas amenazas en tu red doméstica mediante segmentación de Wi-Fi impide que los atacantes usen tus electrodomésticos como puente hacia tu empresa. \"Enhorabuena por completar el Módulo 4. Has asimilado la importancia vital de extender el perímetro de seguridad corporativa hasta tu propio domicilio. La gestión de las redes domésticas, la segmentación del IoT y el rechazo a prácticas como el Shadow IT garantizan que la eficiencia del teletrabajo no comprometa la integridad de la organización. A continuación, nos adentraremos en qué hacer exactamente cuando, a pesar de toda la prevención, se produce un incidente.\"",
      "id": 69
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 66",
      "title": "Resultados y Feedback del Módulo 4",
      "visual_title": "Corrección y Retroalimentación: Módulo 4",
      "text_on_screen": [
        "• Q1: Correcta [C] - Feedback: La política de mesa limpia y pantalla bloqueada es obligatoria en cualquier entorno. Un equipo desbloqueado en un lugar público es una brecha de seguridad crítica en potencia. El atajo de bloqueo rápido (Win+L) debe ser un acto reflejo.",
        "• Q2: Correcta [B] - Feedback: La VPN no mejora la velocidad, sino la seguridad. Su función es cifrar los datos que viajan por redes no seguras (como el Wi-Fi de tu casa o el de un hotel), impidiendo que ciberdelincuentes puedan leer o manipular la información corporativa en tránsito.",
        "• Q3: Correcta [C] - Feedback: El Shadow IT ocurre cuando los empleados utilizan software no auditado (como conversores de archivos online o IAs gratuitas) para trabajar. Esto destruye la trazabilidad de los datos y viola flagrantemente el RGPD y las políticas de la empresa.",
        "• Q4: Correcta [B] - Feedback: La Ley de Trabajo a Distancia y el ENS son claros. El equipo es de uso exclusivamente profesional y personal; permitir que familiares o visitas interactúen con el equipo o visualicen la pantalla expone a la organización a severas brechas por negligencia humana.",
        "• Q5: Correcta [B] - Feedback: Los dispositivos IoT (Internet of Things) suelen tener medidas de seguridad casi nulas y los asistentes de voz graban audio ambiental. Aislar el equipo corporativo de estas amenazas en tu red doméstica mediante segmentación de Wi-Fi impide que los atacantes usen tus electrodomésticos como puente hacia tu empresa."
      ],
      "extended_text": [
        "\"Enhorabuena por completar el Módulo 4. Has asimilado la importancia vital de extender el perímetro de seguridad corporativa hasta tu propio domicilio. La gestión de las redes domésticas, la segmentación del IoT y el rechazo a prácticas como el Shadow IT garantizan que la eficiencia del teletrabajo no comprometa la integridad de la organización. A continuación, nos adentraremos en qué hacer exactamente cuando, a pesar de toda la prevención, se produce un incidente.\""
      ],
      "image_desc": null,
      "type": "quiz_feedback",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 0,
      "id": 70
    },
    {
      "module_id": 4,
      "slide_num_str": "Diapositiva 67",
      "title": "La Regla de Oro (El Tiempo es Supervivencia)",
      "visual_title": "",
      "text_on_screen": [
        "• La Regla de Oro: La detección temprana es lo único que salva a la empresa.",
        "• En ciberseguridad, el tiempo no es dinero; el tiempo es supervivencia.",
        "• La Directiva NIS2 y el Esquema Nacional de Seguridad (ENS) exigen que las empresas no solo tengan defensas, sino protocolos claros, rápidos y auditables de respuesta frente a incidentes.",
        "• Tu objetivo: Identificar que \"algo no va bien\" y reportarlo en los primeros 5 minutos puede evitar que un virus se propague a toda la red nacional o europea."
      ],
      "extended_text": [
        "\"Hemos llegado al punto crítico. Por mucha formación, firewalls y políticas de prevención que implementemos, el riesgo cero no existe. Las empresas asumen que, tarde o temprano, sufrirán un incidente de seguridad. Cuando esto ocurre, entramos en una carrera contrarreloj.",
        "La Directiva NIS2 de la Unión Europea y el ENS en España han cambiado el enfoque de la seguridad: ya no basta con intentar construir muros impenetrables; ahora la ley exige que demostremos cómo reaccionamos cuando el muro cae. En un ataque de Ransomware, un virus puede cifrar miles de archivos por minuto. Si un empleado detecta una anomalía y duda durante una hora por miedo a equivocarse, el daño será irreversible. Tu capacidad para detectar que 'algo no va bien' y levantar la mano en los primeros 5 minutos es la barrera más efectiva para salvar la infraestructura y garantizar la supervivencia operativa de la organización.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Seguridad en el Entorno Híbrido",
      "time": 60,
      "id": 71
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 68",
      "title": "Los Síntomas de la Infección (Técnicos y Legales)",
      "visual_title": "¿Cómo saber que estamos bajo ataque? (Síntomas y Alertas)",
      "text_on_screen": [
        "Debes estar en alerta máxima ante los siguientes \"síntomas\" en tu equipo:",
        "Comportamiento errático: El ratón se mueve solo, se abren ventanas de comandos repentinas (pantallas negras con letras blancas) o el equipo va extremadamente lento sin razón aparente.",
        "Archivos ilegibles: Los iconos de tus documentos cambian de forma, no puedes abrirlos, o ves que las extensiones han cambiado a formatos extraños (ej. .locked, .crypto).",
        "Alertas de seguridad inusuales: Recibes avisos de intentos de inicio de sesión desde lugares donde no estás.",
        "Firmas no autorizadas (eIDAS): Detectas que se han firmado documentos o aprobado transacciones con tu Identidad Digital o Certificado sin tu consentimiento."
      ],
      "extended_text": [
        "\"Un ciberataque casi nunca se anuncia con una calavera roja gigante en medio de la pantalla, como en las películas. A menudo, es un proceso silencioso. Sin embargo, el malware siempre deja huellas en el rendimiento del equipo. Debes estar atento al comportamiento de tu ordenador. Si notas que el cursor se mueve por sí solo o aparecen ventanas de comandos que se abren y cierran rápidamente, es un indicio claro de ejecución de código en segundo plano. Aún más grave es el cifrado de archivos. Si intentas abrir un PDF o un Excel y el sistema te dice que está dañado, y notas que el nombre del archivo ahora termina en .locked o .crypto, estás presenciando un ataque de Ransomware en tiempo real.",
        "Además, bajo los estándares eIDAS, debes vigilar tu Identidad Digital. Si recibes un correo confirmando una firma electrónica que tú no has realizado, tu identidad ha sido robada. En ese momento, cada segundo que el ordenador siga conectado a la red, docenas de archivos o contratos adicionales estarán siendo secuestrados o firmados de forma fraudulenta.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 60,
      "id": 72
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 69",
      "title": "El Protocolo de Actuación - Pasos 1 y 2",
      "visual_title": "Actuación Inmediata: 1, 2, 3 (Contener la amenaza)",
      "text_on_screen": [
        "• Paso 1. Mantener la calma: El pánico lleva a tomar decisiones impulsivas. No intentes arreglar el problema por tu cuenta (el error humano causa más daño). Prohibido consultar IAs públicas (Shadow AI) para intentar \"limpiar\" el virus introduciendo código de la empresa.",
        "• Paso 2. Desconexión de Red Inmediata: Si sospechas que tu equipo está comprometido, córtale el acceso a internet y a la red corporativa al instante.",
        "Desconecta el cable Ethernet físicamente.",
        "Apaga la antena Wi-Fi del portátil."
      ],
      "extended_text": [
        "\"Ante la detección de un síntoma, la primera reacción suele ser el pánico o la vergüenza, especialmente si creemos que nosotros hemos provocado el incidente (por ejemplo, al hacer clic en un enlace engañoso).",
        "Paso 1: Mantén la calma. Intentar revertir el proceso, borrar el correo o ejecutar un antivirus gratuito descargado de internet para intentar solucionarlo sin que nadie se entere solo agravará la situación. Bajo ningún concepto copies fragmentos de código del error y los pegues en una IA pública pidiendo ayuda, ya que estarías exponiendo los sistemas a terceros.",
        "Paso 2: La Desconexión de Red. La inmensa mayoría del software malicioso necesita comunicarse con su servidor de control (el centro de mando del hacker) para recibir las claves de cifrado o para enviar fuera de la empresa los datos robados. Al arrancar el cable de red o apagar el Wi-Fi de forma manual e inmediata, actúas como un cortafuegos físico: aíslas tu ordenador y evitas que el ataque se propague al resto de la organización.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 60,
      "id": 73
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 70",
      "title": "El Protocolo de Actuación - Pasos 3 y 4",
      "visual_title": "Actuación Inmediata: Preservar y Reportar",
      "text_on_screen": [
        "Paso 3. No apagar el equipo afectado: A menos que IT te lo ordene expresamente, no apagues el ordenador. Apagarlo borra la memoria RAM, destruyendo evidencias clave y posibles claves de descifrado.",
        "Paso 4. Reporte a través de Canal Oficial: Informa de inmediato usando una vía segura (Ej. teléfono de emergencias IT o móvil corporativo). Nunca uses el equipo infectado para enviar un correo de alerta."
      ],
      "extended_text": [
        "\"Uno de los errores más comunes y destructivos durante un incidente es el instinto de apagar el ordenador 'tirando del cable' de la corriente. El Paso 3 prohíbe tajantemente apagar el equipo. Cuando un ordenador se apaga, toda la información volátil almacenada en la memoria RAM desaparece. Esa memoria RAM es exactamente donde los expertos de seguridad y peritos informáticos buscan el rastro del malware y, lo que es más importante, las claves criptográficas que el virus está usando para cifrar tus archivos. Si lo apagas, destruyes la evidencia técnica que podría salvar los datos. Déjalo encendido y desconectado de la red.",
        "Finalmente, el Paso 4: Reporta. No uses el ordenador afectado para enviar un correo de socorro, ya que el atacante podría estar interceptando tus comunicaciones. Utiliza tu teléfono móvil corporativo o llama directamente al equipo de Soporte IT para informar del incidente.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 60,
      "id": 74
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 71",
      "title": "Preservación de Evidencias (Cadena de Custodia)",
      "visual_title": "Justicia Digital y la Cadena de Custodia",
      "text_on_screen": [
        "• Según el RD-ley 6/2023 (Decreto Ómnibus), las pruebas digitales tienen plena validez en un juicio siempre que no hayan sido manipuladas.",
        "• La Cadena de Custodia: Cualquier intento del usuario de \"limpiar\" el virus o manipular carpetas puede comprometer la integridad de las pruebas digitales.",
        "• Consecuencia legal: Si la evidencia se manipula, la empresa no podrá denunciar el ataque ni utilizar los datos para su defensa legal. ¡Deja que los expertos trabajen!"
      ],
      "extended_text": [
        "\"En ciberseguridad corporativa no solo buscamos recuperar los ordenadores, también debemos preparar el escenario para una actuación legal o policial. El Real Decreto-ley 6/2023 (Decreto Ómnibus) establece que las evidencias digitales tienen plena validez jurídica, pero están sujetas a un control estricto: la Cadena de Custodia. Si un empleado, asustado por haber descargado un troyano, intenta borrar su historial de navegación, elimina correos o intenta desinstalar programas para ocultar su error, está destruyendo pruebas. Esta manipulación podría anular por completo la validez de la evidencia digital en un juicio.",
        "Si la empresa necesita denunciar el ataque a las autoridades o reclamar los daños al seguro de ciberriesgos, la aseguradora o el juez podrían denegar el caso porque la escena del crimen informático fue contaminada por el propio usuario. Ante un ataque, aparta las manos del teclado y deja que los peritos forenses extraigan los registros.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 60,
      "id": 75
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 72",
      "title": "Confidencialidad y Redes Sociales durante el Ataque",
      "visual_title": "El Peligro del Pánico Social",
      "text_on_screen": [
        "• Confidencialidad absoluta del Incidente: Durante un ataque, es vital no divulgar información en redes sociales ni en grupos de WhatsApp externos.",
        "• El Riesgo Operativo: Compartir detalles (\"Se ha caído el sistema\", \"Nos han hackeado\") alerta al atacante de que los hemos descubierto, complicando la respuesta.",
        "• El Riesgo Legal: Las filtraciones dañan gravemente la reputación de la empresa y pueden desencadenar responsabilidades y pánico en los clientes."
      ],
      "extended_text": [
        "\"En el fragor de un ciberataque, cuando los sistemas se caen y reina la incertidumbre, es muy tentador coger el teléfono personal y escribir en un grupo de WhatsApp o en Twitter: 'Caos en la oficina, nos han metido un virus y no funciona nada'. Esto es un fallo gravísimo de confidencialidad.",
        "Primero, porque si el ciberdelincuente monitoriza las redes sociales de los empleados (lo cual es muy común), se enterará en tiempo real de que la empresa se ha dado cuenta del ataque, y acelerará la extracción de datos o la destrucción de los servidores antes de que podamos detenerlo.",
        "Segundo, porque una filtración pública no controlada destruye la reputación de la organización, provoca pánico injustificado en los accionistas y clientes, e incumple los protocolos de comunicación corporativa. Durante un incidente, la comunicación debe ser estrictamente interna y canalizada por los responsables.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 60,
      "id": 76
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 73",
      "title": "La Cultura de \"No Culpa\" y Canales de Denuncia",
      "visual_title": "Cultura de Transparencia y Ley 2/2023",
      "text_on_screen": [
        "• La Cultura de \"No Culpa\": Fomentamos un entorno de transparencia. El valor de un empleado no se mide por no cometer errores, sino por su rapidez y honestidad al reportarlos.",
        "• Ocultar un error agrava el daño; reportarlo de inmediato nos permite solucionarlo eficazmente.",
        "• El Canal de Denuncias (Ley 2/2023): Herramienta oficial, segura y anónima para reportar malas prácticas, negligencias sistemáticas o incidentes graves ocultados por superiores. Protege legalmente al informante contra represalias."
      ],
      "extended_text": [
        "\"Para que el protocolo de respuesta a incidentes funcione, la empresa adopta una filosofía indispensable: la Cultura de 'No Culpa'. Sabemos que las técnicas de ingeniería social están diseñadas para engañar al cerebro humano; cualquier persona, incluido el CEO, puede ser víctima de un Phishing sofisticado. Lo que la empresa penaliza no es el error involuntario de hacer clic en un enlace, sino la ocultación dolosa de ese error. Si cometiste un fallo, repórtalo al instante. Esa honestidad es lo que salvará a la organización.",
        "Asimismo, si observas negligencias sistemáticas en tu departamento durante una crisis (por ejemplo, si un directivo decide ocultar una brecha masiva de datos en lugar de reportarla según el protocolo ENS o RGPD), tienes a tu disposición el Canal de Denuncias interno, amparado por la Ley 2/2023 de Protección del Informante. Este canal garantiza el anonimato total y protege al empleado frente a cualquier tipo de represalia laboral, asegurando que los incidentes graves salgan a la luz.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 60,
      "id": 77
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 75",
      "title": "Pregunta 1",
      "visual_title": "Quiz Módulo 5: Supera la Evaluación (Esta pantalla bloquea el avance del alumno en el LMS hasta que responda correctamente).",
      "text_on_screen": [
        "Pregunta 1: Notas que tu ordenador empieza a abrir ventanas de comandos por sí solo y que algunos archivos han cambiado su nombre con una extensión extraña (ej. .locked). ¿Qué es lo primero que debes hacer?",
        "• [A] Apagar el ordenador de la corriente inmediatamente.",
        "• [B] Reiniciar el equipo para ver si el problema se soluciona solo.",
        "• [C] Desconectar el cable de red o apagar el Wi-Fi para aislarlo y reportar el incidente al canal oficial corporativo.",
        "• [D] Buscar ayuda pegando el código de error en una Inteligencia Artificial pública."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 45,
      "question_text": "Notas que tu ordenador empieza a abrir ventanas de comandos por sí solo y que algunos archivos han cambiado su nombre con una extensión extraña (ej. .locked). ¿Qué es lo primero que debes hacer?",
      "options": [
        {
          "id": "A",
          "text": "Apagar el ordenador de la corriente inmediatamente."
        },
        {
          "id": "B",
          "text": "Reiniciar el equipo para ver si el problema se soluciona solo."
        },
        {
          "id": "C",
          "text": "Desconectar el cable de red o apagar el Wi-Fi para aislarlo y reportar el incidente al canal oficial corporativo."
        },
        {
          "id": "D",
          "text": "Buscar ayuda pegando el código de error en una Inteligencia Artificial pública."
        }
      ],
      "correct_answer": "C",
      "feedback": "Desconectar la red es el paso vital. Al quitar el cable o el Wi-Fi, actúas como un cortafuegos físico, impidiendo que el malware se propague por los servidores o envíe datos al exterior. Nunca uses Shadow AI en crisis. •",
      "id": 78
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 76",
      "title": "Pregunta 2",
      "visual_title": "Quiz Módulo 5: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 2: ¿Por qué es una regla fundamental NO apagar el ordenador infectado (a menos que el equipo de IT lo ordene expresamente)?",
        "• [A] Porque tarda mucho tiempo en volver a encenderse.",
        "• [B] Porque al apagarlo se borra la memoria RAM, destruyendo evidencias clave y posibles claves criptográficas para el descifrado del ataque.",
        "• [C] Porque el virus se propaga mucho más rápido cuando el equipo está apagado.",
        "• [D] Porque apagarlo consume mucha energía eléctrica."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 45,
      "question_text": "¿Por qué es una regla fundamental NO apagar el ordenador infectado (a menos que el equipo de IT lo ordene expresamente)?",
      "options": [
        {
          "id": "A",
          "text": "Porque tarda mucho tiempo en volver a encenderse."
        },
        {
          "id": "B",
          "text": "Porque al apagarlo se borra la memoria RAM, destruyendo evidencias clave y posibles claves criptográficas para el descifrado del ataque."
        },
        {
          "id": "C",
          "text": "Porque el virus se propaga mucho más rápido cuando el equipo está apagado."
        },
        {
          "id": "D",
          "text": "Porque apagarlo consume mucha energía eléctrica."
        }
      ],
      "correct_answer": "B",
      "feedback": "La memoria RAM es volátil y desaparece al cortar la corriente. Los peritos forenses necesitan el equipo encendido para extraer el rastro del malware y encontrar las claves criptográficas para recuperar los datos. •",
      "id": 79
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 77",
      "title": "Pregunta 3",
      "visual_title": "Quiz Módulo 5: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 3: Según el RD-ley 6/2023, ¿qué consecuencia legal tiene que un empleado intente borrar el historial o manipular un equipo infectado para ocultar su error tras un ciberataque?",
        "• [A] Rompe la cadena de custodia, anulando la validez de la prueba digital en un juicio, seguro o denuncia oficial.",
        "• [B] La empresa recibe una subvención por intentar solucionarlo internamente.",
        "• [C] Ninguna, el seguro de ciberriesgos asume toda la responsabilidad y paga sin investigar.",
        "• [D] Demuestra que el empleado es proactivo y competente."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 45,
      "question_text": "Según el RD-ley 6/2023, ¿qué consecuencia legal tiene que un empleado intente borrar el historial o manipular un equipo infectado para ocultar su error tras un ciberataque?",
      "options": [
        {
          "id": "A",
          "text": "Rompe la cadena de custodia, anulando la validez de la prueba digital en un juicio, seguro o denuncia oficial."
        },
        {
          "id": "B",
          "text": "La empresa recibe una subvención por intentar solucionarlo internamente."
        },
        {
          "id": "C",
          "text": "Ninguna, el seguro de ciberriesgos asume toda la responsabilidad y paga sin investigar."
        },
        {
          "id": "D",
          "text": "Demuestra que el empleado es proactivo y competente."
        }
      ],
      "correct_answer": "A",
      "feedback": "La manipulación del equipo por personal no experto destruye la Cadena de Custodia. Si la evidencia se adultera, un juez la desestimará, impidiendo que la empresa pueda defenderse legalmente. •",
      "id": 80
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 78",
      "title": "Pregunta 4",
      "visual_title": "Quiz Módulo 5: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 4: Durante una crisis en la oficina, un directivo te ordena no reportar la exposición de una base de datos pública para \"evitar sanciones del ENS y la AEPD\", contraviniendo el protocolo. ¿Qué herramienta de protección tienes?",
        "• [A] Acatar la orden para mantener mi puesto de trabajo.",
        "• [B] Publicarlo en Twitter para que los clientes se enteren y se protejan solos.",
        "• [C] Utilizar el Canal de Denuncias interno (Ley 2/2023), que protege mi anonimato y me blinda legalmente contra represalias por reportar ocultaciones dolosas."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 45,
      "question_text": "Durante una crisis en la oficina, un directivo te ordena no reportar la exposición de una base de datos pública para \"evitar sanciones del ENS y la AEPD\", contraviniendo el protocolo. ¿Qué herramienta de protección tienes?",
      "options": [
        {
          "id": "A",
          "text": "Acatar la orden para mantener mi puesto de trabajo."
        },
        {
          "id": "B",
          "text": "Publicarlo en Twitter para que los clientes se enteren y se protejan solos."
        },
        {
          "id": "C",
          "text": "Utilizar el Canal de Denuncias interno (Ley 2/2023), que protege mi anonimato y me blinda legalmente contra represalias por reportar ocultaciones dolosas."
        }
      ],
      "correct_answer": "C",
      "feedback": "La ocultación deliberada de una brecha agrava exponencialmente la responsabilidad penal de la empresa. La Ley 2/2023 (Whistleblowing) te otorga protección absoluta para denunciar internamente a quienes ordenen ocultar incidentes. •",
      "id": 81
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 79",
      "title": "Pregunta 5",
      "visual_title": "Quiz Módulo 5: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 5: ¿Qué significa exactamente implementar la \"Cultura de No Culpa\" en el plan de ciberseguridad y resiliencia de la empresa?",
        "• [A] Que los hackers nunca son considerados legalmente culpables de sus delitos.",
        "• [B] Que la empresa asume que nadie es responsable de nada de lo que ocurra en la oficina.",
        "• [C] Que se prioriza y valora el reporte rápido y honesto de los errores humanos para mitigar daños, eliminando el miedo al castigo en el trabajador.",
        "• [D] Que los empleados no tienen que pedir disculpas si llegan tarde."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 45,
      "question_text": "¿Qué significa exactamente implementar la \"Cultura de No Culpa\" en el plan de ciberseguridad y resiliencia de la empresa?",
      "options": [
        {
          "id": "A",
          "text": "Que los hackers nunca son considerados legalmente culpables de sus delitos."
        },
        {
          "id": "B",
          "text": "Que la empresa asume que nadie es responsable de nada de lo que ocurra en la oficina."
        },
        {
          "id": "C",
          "text": "Que se prioriza y valora el reporte rápido y honesto de los errores humanos para mitigar daños, eliminando el miedo al castigo en el trabajador."
        },
        {
          "id": "D",
          "text": "Que los empleados no tienen que pedir disculpas si llegan tarde."
        }
      ],
      "correct_answer": "C",
      "feedback": "La Ingeniería Social está diseñada para engañar al cerebro. La \"Cultura de No Culpa\" fomenta la transparencia; si cometes un error, lo verdaderamente importante y valiente es reportarlo al instante sin temor a represalias.",
      "id": 82
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 80",
      "title": "Resultados y Feedback del Módulo 5",
      "visual_title": "Corrección y Retroalimentación: Módulo 5",
      "text_on_screen": [
        "• Q1: Correcta [C] - Feedback: Desconectar la red es el paso vital. Al quitar el cable o el Wi-Fi, actúas como un cortafuegos físico, impidiendo que el malware se propague por los servidores o envíe datos al exterior. Nunca uses Shadow AI en crisis.",
        "• Q2: Correcta [B] - Feedback: La memoria RAM es volátil y desaparece al cortar la corriente. Los peritos forenses necesitan el equipo encendido para extraer el rastro del malware y encontrar las claves criptográficas para recuperar los datos.",
        "• Q3: Correcta [A] - Feedback: La manipulación del equipo por personal no experto destruye la Cadena de Custodia. Si la evidencia se adultera, un juez la desestimará, impidiendo que la empresa pueda defenderse legalmente.",
        "• Q4: Correcta [C] - Feedback: La ocultación deliberada de una brecha agrava exponencialmente la responsabilidad penal de la empresa. La Ley 2/2023 (Whistleblowing) te otorga protección absoluta para denunciar internamente a quienes ordenen ocultar incidentes.",
        "• Q5: Correcta [C] - Feedback: La Ingeniería Social está diseñada para engañar al cerebro. La \"Cultura de No Culpa\" fomenta la transparencia; si cometes un error, lo verdaderamente importante y valiente es reportarlo al instante sin temor a represalias."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_feedback",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 0,
      "id": 83
    },
    {
      "module_id": 5,
      "slide_num_str": "Diapositiva 81",
      "title": "La Mente: El Factor Olvidado",
      "visual_title": "",
      "text_on_screen": [
        "• El factor olvidado: A menudo pensamos en la ciberseguridad como algo frío y técnico (servidores, firewalls, códigos).",
        "• El verdadero riesgo: La presión de estar \"siempre conectados\" y el miedo a cometer un error generan nuevos riesgos para la salud de la plantilla.",
        "• Resiliencia Digital Integral: En la actualidad, no solo se trata de proteger la infraestructura de los servidores, sino de proteger la capacidad cognitiva y el bienestar del trabajador."
      ],
      "extended_text": [
        "\"Llegamos al último pilar de la ciberseguridad corporativa, y paradójicamente, es el menos técnico de todos: tu propia mente.",
        "Durante décadas, la industria ha tratado la seguridad informática como una batalla de máquinas contra máquinas. Hoy sabemos que es una batalla psicológica. Un empleado agotado, estresado o sobrepasado por las alertas de seguridad es infinitamente más propenso a cometer el error que un atacante está esperando. La falta de sueño o el estrés crónico reducen nuestra capacidad de atención focalizada y nuestro pensamiento crítico, que son exactamente las herramientas que necesitamos para detectar un correo de Phishing sofisticado.",
        "Por lo tanto, garantizar el descanso y la salud mental de la plantilla no es solo una obligación de Recursos Humanos; es, en sí misma, una de las medidas de ciberseguridad más efectivas que la organización puede implementar.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Protocolo de Respuesta ante Incidentes",
      "time": 60,
      "id": 84
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 82",
      "title": "Riesgos Psicosociales - El Tecnoestrés y el AI Act",
      "visual_title": "Riesgos Psicosociales Digitales (I): Tecnoestrés y la IA",
      "text_on_screen": [
        "• Tecnoestrés (Ansiedad Digital): Surge cuando las personas sienten que no pueden adaptarse a las exigencias de las nuevas herramientas tecnológicas.",
        "• Gestión Algorítmica (AI Act): La presión por cumplir métricas de productividad dictadas por sistemas automatizados o Inteligencias Artificiales genera un desgaste cognitivo severo.",
        "• El Impacto: Genera una sensación de estar constantemente abrumado, afectando tanto a la productividad operativa como al bienestar personal.",
        "• La Solución: Es fundamental desarrollar estrategias corporativas para equilibrar el uso de la tecnología y reducir su impacto negativo."
      ],
      "extended_text": [
        "\"La digitalización acelerada ha traído consigo nuevas patologías laborales. La primera de ellas es el Tecnoestrés. Este fenómeno aparece cuando un empleado percibe una brecha insalvable entre lo que la tecnología corporativa le exige (aprender nuevos softwares de gestión, nuevas plataformas de comunicación, nuevos protocolos de verificación) y su capacidad para asimilarlo todo a la vez. A esto se suma un riesgo muy actual regulado por el AI Act: la gestión algorítmica. Si los empleados sienten que una Inteligencia Artificial monitoriza cada uno de sus clics o tiempos de respuesta para evaluar su rendimiento, el nivel de estrés se dispara. Esta incapacidad percibida no refleja una falta de competencia profesional, sino una saturación cognitiva.",
        "El empleado se siente perpetuamente abrumado y frustrado, lo que desencadena un círculo vicioso: a mayor ansiedad, menor rendimiento y mayor probabilidad de cometer errores de seguridad crítica. La empresa aborda este riesgo fomentando planes de formación escalonados (como este) y promoviendo una adaptación tecnológica sostenible.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 60,
      "id": 85
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 83",
      "title": "Riesgos Psicosociales - Fatiga por Alertas",
      "visual_title": "Riesgos Psicosociales Digitales (II): La Fatiga por Alertas",
      "text_on_screen": [
        "• Fatiga por Alertas Constantes: Ocurre cuando el trabajador recibe un flujo incesante de notificaciones, correos electrónicos y avisos de seguridad.",
        "• El Riesgo de Ciberseguridad: Este bombardeo debilita las defensas, llevando al empleado a ignorar mensajes verdaderamente importantes por puro agotamiento.",
        "• Mitigación: Implementar filtros y priorizar notificaciones es clave para resolver la saturación de atención."
      ],
      "extended_text": [
        "\"El segundo riesgo crítico es lo que en ingeniería de sistemas llamamos 'Alert Fatigue' o Fatiga por Alertas.",
        "Piensa en tu día a día: notificaciones de Teams, correos entrantes, el móvil vibrando, ventanas emergentes del antivirus pidiendo actualizaciones... Cuando el cerebro humano es sometido a un flujo constante e ininterrumpido de estímulos, entra en un mecanismo de autodefensa llamado desensibilización sistemática. Es decir, dejamos de prestar atención.",
        "El peligro extremo de esto es que, en medio de 50 notificaciones irrelevantes, puede esconderse una alerta crítica de un acceso no autorizado a tu cuenta. El trabajador, agotado por el ruido digital, ignora el mensaje real, debilitando la defensa de la empresa. Gestionar y filtrar las notificaciones para que solo salten las urgentes no es un lujo, es una táctica de supervivencia.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 60,
      "id": 86
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 84",
      "title": "Riesgos Psicosociales - Ciber-ansiedad",
      "visual_title": "Riesgos Psicosociales Digitales (III): Ciber-ansiedad",
      "text_on_screen": [
        "• Ciber-ansiedad: Miedo constante a ser víctima de un ciberataque o a ser el responsable directo de un incidente en la empresa.",
        "• La Parálisis: Este temor paraliza al empleado, dificultando la toma de decisiones rápidas y efectivas en momentos de crisis.",
        "• La Defensa: Fomentar una cultura de confianza y capacitación continua. El conocimiento anula el miedo irracional."
      ],
      "extended_text": [
        "\"El tercer gran riesgo psicosocial es la Ciber-ansiedad. A medida que los empleados son más conscientes de los riesgos y las multas millonarias asociadas a la pérdida de datos y a las sanciones de normativas como el ENS o el RGPD, puede aflorar un terror paralizante a 'tocar algo que no deben' o a ser señalados como los culpables de hundir la empresa. Este miedo excesivo es contraproducente. La ciber-ansiedad paraliza la toma de decisiones.",
        "Un empleado aterrorizado dudará a la hora de reportar una anomalía, o evitará utilizar herramientas tecnológicas legítimas que harían su trabajo más eficiente, por miedo a equivocarse. Saber exactamente cómo actúan los atacantes y tener un protocolo claro (como vimos en el Módulo 5) sustituye la ansiedad irracional por una preparación estructurada.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 60,
      "id": 87
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 85",
      "title": "La Barrera Legal de la Desconexión y el Whistleblowing",
      "visual_title": "Derecho a la Desconexión Digital (Art. 88) y Ley 2/2023 Texto Principal (En pantalla):",
      "text_on_screen": [
        "• El Art. 88 de la LOPDGDD: Establece legalmente el derecho de los trabajadores a desconectarse digitalmente fuera de su horario laboral.",
        "• No Obligatoriedad: No estás obligado a responder correos, mensajes de WhatsApp o Teams una vez finalizada tu jornada.",
        "• El Objetivo: Combatir la fatiga informativa y garantizar un equilibrio ético y saludable entre la vida personal y profesional.",
        "• Canal de Denuncias (Ley 2/2023): Si sufres presiones sistemáticas para ignorar tu desconexión, tienes derecho a reportar este abuso a través del canal interno oficial."
      ],
      "extended_text": [
        "\"Para proteger la salud mental de la plantilla, la ley española ha establecido una frontera inquebrantable. El Artículo 88 de la Ley Orgánica de Protección de Datos y Garantía de los Derechos Digitales (LOPDGDD) consagra el Derecho a la Desconexión Digital. Esto significa que el cierre de la jornada laboral marca el fin de tu disponibilidad. Legalmente, no estás obligado a leer, y mucho menos a responder, comunicaciones corporativas fuera de tu horario estipulado, sin importar si llegan por correo, chat o plataformas de mensajería instantánea.",
        "Las empresas están obligadas a respetar este principio para fomentar la sostenibilidad laboral y combatir el agotamiento cognitivo. Un cerebro descansado y desconectado es un cerebro mucho más alerta y capaz de detectar fraudes al día siguiente. Además, la Ley 2/2023 te ampara. Si un mando intermedio te exige sistemáticamente conectarte de madrugada o los fines de semana bajo amenaza, puedes y debes utilizar el Canal de Denuncias interno para reportar esta infracción de los estatutos laborales con total protección frente a represalias.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 60,
      "id": 88
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 86",
      "title": "Límites del Teletrabajo y Excepciones de Seguridad",
      "visual_title": "Excepciones de Seguridad y Límites del Modelo Híbrido",
      "text_on_screen": [
        "• Límites del Teletrabajo: El teletrabajo no implica disponibilidad constante las 24 horas del día. Deben respetarse los horarios pactados para proteger la salud mental.",
        "• Excepciones de Seguridad: En casos excepcionales de fuerza mayor (como un incidente crítico de seguridad), puede requerirse la intervención fuera del horario habitual.",
        "• Estas situaciones anómalas deben estar claramente reguladas y contar con protocolos de compensación justos."
      ],
      "extended_text": [
        "\"El trabajo a distancia ha difuminado las fronteras físicas, pero no debe difuminar las fronteras temporales. El teletrabajo no es un pase libre para exigir disponibilidad 24/7. Respetar los horarios es imprescindible para mantener la higiene mental. Ahora bien, ¿existe alguna excepción al derecho a la desconexión? Sí, la supervivencia operativa de la empresa.",
        "En el contexto de este curso, la Excepción de Seguridad aplica ante un ciberataque inminente o un incidente crítico. Si se detecta que desde tu cuenta se está propagando un ransomware un sábado por la tarde, el equipo de IT contactará contigo de emergencia para confirmar el bloqueo de tus accesos. Estas intervenciones son de fuerza mayor, están tasadas legalmente y deben ir acompañadas de sistemas de compensación, garantizando que el derecho al descanso no se vea vulnerado de forma sistemática.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 60,
      "id": 89
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 87",
      "title": "La Ética Digital y la \"No Culpa\"",
      "visual_title": "Ética Digital: Hacia una Cultura de la \"No Culpa\"",
      "text_on_screen": [
        "• Aceptar los Errores Humanos: Todos somos susceptibles de hacer clic en un enlace incorrecto o perder un dispositivo.",
        "• Transparencia Total: El valor de un profesional no se mide por la ausencia de errores, sino por su rapidez y honestidad al reportarlos.",
        "• Promover la Responsabilidad Ética: El uso de la tecnología debe estar guiado por principios justos, no solo monitoreado para castigar."
      ],
      "extended_text": [
        "\"Llegamos al núcleo de nuestra ética corporativa: la Cultura de la 'No Culpa'. Históricamente, las organizaciones castigaban severamente al empleado que traía un virus a la oficina. ¿El resultado? Los empleados aterrorizados ocultaban sus errores, permitiendo que las infecciones destruyeran los servidores durante días antes de ser descubiertas.",
        "Hemos aprendido la lección. Sabemos que los atacantes utilizan IA y neurociencia para engañarnos. Asumimos y aceptamos que todos, desde el becario hasta el CEO, pueden cometer un error humano. Lo que pedimos a cambio de esta comprensión es una Transparencia Total. Promover la responsabilidad ética significa que si haces clic donde no debías, debes levantar la mano inmediatamente. Abordar los problemas sin miedo al juicio o a la reprimenda es lo que crea un entorno de colaboración y confianza, protegiendo tanto a la empresa como a los individuos que la componen.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 60,
      "id": 90
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 88",
      "title": "Justificación para Auditores (Compliance PRD-M6)",
      "visual_title": "Nota de Cumplimiento para Auditoría (PRD-M6) (Documento oficial de evidencia normativa)",
      "text_on_screen": [
        "Este bloque da herramientas para formar a los empleados para cumplir con:",
        "Ley 31/1995 de PRL: Prevención específica de Riesgos Psicosociales (Tecnoestrés, Ciber-ansiedad).",
        "LOPDGDD (Art. 88): Capacitación y respeto absoluto del Derecho a la Desconexión Digital.",
        "Directiva NIS2 y ENS: Fomento de una cultura de seguridad integral, preventiva y libre de represalias.",
        "AI Act y Ley 2/2023: Mitigación de riesgos laborales asociados a la presión algorítmica y dotación de canales seguros para reportar abusos normativos."
      ],
      "extended_text": [
        "\"A nivel de auditoría laboral y de seguridad, este módulo cierra el círculo del cumplimiento normativo. Una inspección de trabajo o un auditor de la normativa ISO no solo evaluará nuestros cortafuegos, sino también si estamos previniendo las enfermedades laborales derivadas del uso de la tecnología. Al impartir este módulo, la organización demuestra documentalmente que está actuando frente a los Riesgos Psicosociales exigidos por la Ley de Prevención de Riesgos Laborales (PRL). Además, fomenta el respeto al Estatuto de los Trabajadores y el Artículo 88 de la LOPDGDD respecto a la Desconexión Digital.",
        "Finalmente, integra la Alfabetización exigida por el AI Act y la cultura de reporte de la Ley 2/2023, garantizando un ecosistema resiliente y ético.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 60,
      "id": 91
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 89",
      "title": "Pregunta 1",
      "visual_title": "Quiz Módulo 6: Supera la Evaluación (Esta pantalla bloquea el avance del alumno en el LMS hasta que responda correctamente).",
      "text_on_screen": [
        "Pregunta 1: ¿Qué establece exactamente el Artículo 88 de la LOPDGDD respecto a la desconexión digital?",
        "• [A] Que los trabajadores tienen derecho a no responder comunicaciones de trabajo fuera de su jornada legal estipulada.",
        "• [B] Que el trabajador debe responder correos en menos de 2 horas en todo momento.",
        "• [C] Que está prohibido usar el teléfono móvil personal durante la jornada de trabajo."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 45,
      "question_text": "¿Qué establece exactamente el Artículo 88 de la LOPDGDD respecto a la desconexión digital?",
      "options": [
        {
          "id": "A",
          "text": "Que los trabajadores tienen derecho a no responder comunicaciones de trabajo fuera de su jornada legal estipulada."
        },
        {
          "id": "B",
          "text": "Que el trabajador debe responder correos en menos de 2 horas en todo momento."
        },
        {
          "id": "C",
          "text": "Que está prohibido usar el teléfono móvil personal durante la jornada de trabajo."
        }
      ],
      "correct_answer": "A",
      "feedback": "El Art. 88 garantiza que el cierre de jornada marca el fin de la disponibilidad, protegiendo al empleado de la carga mental excesiva. •",
      "id": 92
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 90",
      "title": "Pregunta 2",
      "visual_title": "Quiz Módulo 6: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 2: ¿Por qué la \"Fatiga por Alertas\" es considerada un grave riesgo de ciberseguridad para la empresa?",
        "• [A] Porque gasta rápidamente la batería de los dispositivos móviles corporativos.",
        "• [B] Porque ralentiza la velocidad del internet de la oficina.",
        "• [C] Porque el trabajador acaba ignorando avisos reales e importantes debido a la saturación extrema de notificaciones."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 45,
      "question_text": "¿Por qué la \"Fatiga por Alertas\" es considerada un grave riesgo de ciberseguridad para la empresa?",
      "options": [
        {
          "id": "A",
          "text": "Porque gasta rápidamente la batería de los dispositivos móviles corporativos."
        },
        {
          "id": "B",
          "text": "Porque ralentiza la velocidad del internet de la oficina."
        },
        {
          "id": "C",
          "text": "Porque el trabajador acaba ignorando avisos reales e importantes debido a la saturación extrema de notificaciones."
        }
      ],
      "correct_answer": "C",
      "feedback": "La desensibilización por recibir demasiadas alertas hace que ignoremos los mensajes críticos, facilitando la entrada de amenazas en el sistema. •",
      "id": 93
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 91",
      "title": "Pregunta 3",
      "visual_title": "Quiz Módulo 6: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 3: Un superior jerárquico te recrimina habitualmente por no contestar a correos de rutina durante tus fines de semana, violando tu derecho a la desconexión y generándote un fuerte tecnoestrés. ¿Qué medida legal tienes a tu alcance en la empresa?",
        "• [A] Apagar el ordenador de forma definitiva y no volver a la empresa.",
        "• [B] Acatar la norma de ese jefe, ya que las políticas del departamento superan a la ley general.",
        "• [C] Utilizar el Canal de Denuncias (Ley 2/2023) para reportar de forma confidencial este abuso sistemático que atenta contra los riesgos psicosociales y el Artículo 88 de la LOPDGDD."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 45,
      "question_text": "Un superior jerárquico te recrimina habitualmente por no contestar a correos de rutina durante tus fines de semana, violando tu derecho a la desconexión y generándote un fuerte tecnoestrés. ¿Qué medida legal tienes a tu alcance en la empresa?",
      "options": [
        {
          "id": "A",
          "text": "Apagar el ordenador de forma definitiva y no volver a la empresa."
        },
        {
          "id": "B",
          "text": "Acatar la norma de ese jefe, ya que las políticas del departamento superan a la ley general."
        },
        {
          "id": "C",
          "text": "Utilizar el Canal de Denuncias (Ley 2/2023) para reportar de forma confidencial este abuso sistemático que atenta contra los riesgos psicosociales y el Artículo 88 de la LOPDGDD."
        }
      ],
      "correct_answer": "C",
      "feedback": "El bienestar psicosocial está regulado por ley. La Ley 2/2023 ampara al empleado para reportar de forma segura y sin temor a represalias las malas praxis de mandos intermedios que violen la desconexión digital obligatoria. •",
      "id": 94
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 92",
      "title": "Pregunta 4",
      "visual_title": "Quiz Módulo 6: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 4: ¿Es el descanso del empleado una medida técnica de ciberseguridad?",
        "• [A] Sí, porque un trabajador bien descansado tiene una mayor capacidad crítica y atención para detectar engaños, suplantaciones generadas por IA y ataques.",
        "• [B] Solo si el trabajador descansa viendo vídeos formativos sobre tecnología.",
        "• [C] No, es simplemente un derecho regulado en el ámbito laboral."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 45,
      "question_text": "¿Es el descanso del empleado una medida técnica de ciberseguridad?",
      "options": [
        {
          "id": "A",
          "text": "Sí, porque un trabajador bien descansado tiene una mayor capacidad crítica y atención para detectar engaños, suplantaciones generadas por IA y ataques."
        },
        {
          "id": "B",
          "text": "Solo si el trabajador descansa viendo vídeos formativos sobre tecnología."
        },
        {
          "id": "C",
          "text": "No, es simplemente un derecho regulado en el ámbito laboral."
        }
      ],
      "correct_answer": "A",
      "feedback": "Un cerebro agotado no puede procesar los detalles sutiles de un engaño o un Phishing. El descanso es la principal barrera cognitiva. •",
      "id": 95
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 93",
      "title": "Pregunta 5",
      "visual_title": "Quiz Módulo 6: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 5: Ante un conflicto entre una tarea urgente enviada un viernes por la noche y el derecho a la desconexión, ¿cuál es la norma general?",
        "• [A] La urgencia siempre manda, independientemente del horario.",
        "• [B] Apagar el teléfono de empresa y no volver a encenderlo nunca más.",
        "• [C] Respetar siempre el tiempo de descanso, salvo que exista un protocolo de emergencia activado por un incidente crítico de seguridad que comprometa la viabilidad de la empresa."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 45,
      "question_text": "Ante un conflicto entre una tarea urgente enviada un viernes por la noche y el derecho a la desconexión, ¿cuál es la norma general?",
      "options": [
        {
          "id": "A",
          "text": "La urgencia siempre manda, independientemente del horario."
        },
        {
          "id": "B",
          "text": "Apagar el teléfono de empresa y no volver a encenderlo nunca más."
        },
        {
          "id": "C",
          "text": "Respetar siempre el tiempo de descanso, salvo que exista un protocolo de emergencia activado por un incidente crítico de seguridad que comprometa la viabilidad de la empresa."
        }
      ],
      "correct_answer": "C",
      "feedback": "La desconexión es sagrada. Las únicas excepciones que justifican romper el descanso son los eventos de fuerza mayor, como un ciberataque inminente que ponga en riesgo la supervivencia de la empresa.",
      "id": 96
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 94",
      "title": "Resultados y Feedback del Módulo 6",
      "visual_title": "Corrección y Retroalimentación: Módulo 6",
      "text_on_screen": [
        "• Q1: Correcta [A] - Feedback: El Art. 88 garantiza que el cierre de jornada marca el fin de la disponibilidad, protegiendo al empleado de la carga mental excesiva.",
        "• Q2: Correcta [C] - Feedback: La desensibilización por recibir demasiadas alertas hace que ignoremos los mensajes críticos, facilitando la entrada de amenazas en el sistema.",
        "• Q3: Correcta [C] - Feedback: El bienestar psicosocial está regulado por ley. La Ley 2/2023 ampara al empleado para reportar de forma segura y sin temor a represalias las malas praxis de mandos intermedios que violen la desconexión digital obligatoria.",
        "• Q4: Correcta [A] - Feedback: Un cerebro agotado no puede procesar los detalles sutiles de un engaño o un Phishing. El descanso es la principal barrera cognitiva.",
        "• Q5: Correcta [C] - Feedback: La desconexión es sagrada. Las únicas excepciones que justifican romper el descanso son los eventos de fuerza mayor, como un ciberataque inminente que ponga en riesgo la supervivencia de la empresa."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_feedback",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 0,
      "id": 97
    },
    {
      "module_id": 6,
      "slide_num_str": "Diapositiva 96",
      "title": "Introducción a la Gestión de Crisis",
      "visual_title": "",
      "text_on_screen": [
        "• La realidad ineludible: Ningún sistema es 100% invulnerable. La seguridad absoluta es un mito.",
        "• La diferencia entre el éxito y el colapso: No radica en evitar todos los ataques, sino en la velocidad y eficacia con la que la empresa responde cuando el perímetro es vulnerado.",
        "• Tu nuevo rol: Pasar de la prevención pasiva a la detección activa y la mitigación legal."
      ],
      "extended_text": [
        "\"Bienvenidos al Módulo 7. Hasta ahora hemos hablado de cómo levantar escudos, cómo proteger nuestras identidades y cómo aplicar la higiene digital para evitar que las amenazas entren. Pero, ¿qué ocurre el día en que, a pesar de todo, el escudo se rompe?",
        "En el panorama actual, asumir que nunca sufriremos una vulneración es una negligencia estratégica. Las empresas más maduras del mundo sufren incidentes. Lo que diferencia a una organización que sobrevive de una que se enfrenta a multas millonarias y a la ruina reputacional no es el ataque en sí, sino 'El Día Después'. En este módulo aprenderemos cómo actuar con precisión quirúrgica, ética y amparo legal cuando encontramos una grieta en nuestro sistema o, peor aún, cuando los datos de nuestros clientes han quedado expuestos.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Salud Mental y Ética Digital",
      "time": 60,
      "id": 98
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 97",
      "title": "Aclaración de Conceptos: Vulnerabilidad vs. Brecha",
      "visual_title": "Entendiendo la Amenaza: La Grieta frente a la Fuga",
      "text_on_screen": [
        "• Vulnerabilidad: Es una debilidad, un fallo o un \"agujero\" en el sistema, en el software o en un protocolo corporativo. El ladrón aún no ha entrado, pero la puerta está abierta.",
        "• Brecha de Datos (Data Breach): Es el incidente de seguridad consumado. Ocurre cuando información confidencial ha sido accedida, robada, alterada o destruida por un tercero no autorizado.",
        "• La regla básica: Toda brecha de datos proviene de una vulnerabilidad explotada, pero no toda vulnerabilidad termina en una brecha si se detecta y corrige a tiempo."
      ],
      "extended_text": [
        "\"Para aplicar la ley correctamente, primero debemos hablar con propiedad. A menudo, en las noticias, escuchamos que 'se ha descubierto una vulnerabilidad masiva', y cunde el pánico pensando que los datos han sido robados.",
        "Una vulnerabilidad es simplemente una grieta en el muro. Puede ser un software obsoleto o una carpeta de red compartida por error sin contraseña. Si encuentras esa grieta y avisas, has salvado a la empresa.",
        "La Brecha de Datos, sin embargo, es cuando un ciberdelincuente encuentra esa misma grieta antes que tú, entra en el sistema y extrae, altera o secuestra (como en el Ransomware) una base de datos de clientes. Son dos escenarios totalmente distintos que requieren protocolos legales diferentes según el RGPD.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 60,
      "id": 99
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 98",
      "title": "El Límite Operativo y el Triaje Automatizado (AI Act)",
      "visual_title": "El Límite Operativo: Demasiadas Vulnerabilidades, Poco Tiempo",
      "text_on_screen": [
        "• El colapso del sistema tradicional: Actualmente, se descubren miles de nuevas vulnerabilidades de software cada mes. Es operativamente imposible parchearlas todas al instante.",
        "• El Cambio de Paradigma: La ciberseguridad ha llegado a su límite operativo.",
        "• La Solución (Triaje y Protocolos): Las organizaciones deben implementar Guías de Priorización, apoyándose a menudo en Inteligencia Artificial.",
        "• AI Act y Supervisión: Si la empresa usa IA para decidir qué vulnerabilidad parchear primero, la ley europea exige que siempre exista una revisión humana que valide si hay datos personales en riesgo."
      ],
      "extended_text": [
        "\"Vivimos en un momento crítico para la ciberseguridad. Según los últimos análisis del sector de 2026, hemos alcanzado nuestro límite operativo: se descubren tantas vulnerabilidades a diario en los programas que usamos, que los departamentos técnicos literalmente no tienen tiempo material para corregirlas todas antes de que aparezca la siguiente.",
        "La ley y los nuevos estándares exigen implementar protocolos y guías de priorización (Triaje). Hoy en día, las empresas utilizan Inteligencia Artificial para escanear estas vulnerabilidades y decidir cuáles son más urgentes. Sin embargo, en virtud del AI Act, la IA no puede tomar la decisión final de forma autónoma. Si detectamos diez vulnerabilidades, la empresa debe aplicar el juicio humano para identificar rápidamente cuál de ellas pone en peligro inminente los datos personales o la operatividad del negocio, y enfocar todos los recursos en neutralizar esa primero. La eficiencia legal nace de saber priorizar la urgencia.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 60,
      "id": 100
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 99",
      "title": "Actuación al Descubrir una Vulnerabilidad y Whistleblowing",
      "visual_title": "Qué hacer ante una Vulnerabilidad (Protocolo y Ley 2/2023)",
      "text_on_screen": [
        "• 1. Documentar sin explotar: Si descubres un fallo (ej. puedes ver la nómina de otro empleado), anota cómo llegaste ahí, pero NO sigas investigando.",
        "• 2. Reporte inmediato: Informa directamente al CISO o al DPO.",
        "• 3. Silencio absoluto: Prohibido comentarlo con otros compañeros o en redes sociales.",
        "• El Canal de Denuncias (Ley 2/2023): Si la Dirección decide ignorar conscientemente una vulnerabilidad crítica para \"ahorrar costes\", poniendo en riesgo datos de ciudadanos, estás amparado para usar el canal de Whistleblowing corporativo."
      ],
      "extended_text": [
        "\"Imagina que estás navegando por la intranet corporativa y, por un error de configuración, descubres que tienes acceso a los contratos y datos bancarios de toda la plantilla. El instinto de muchos es hacer clic o descargar un archivo para 'demostrarle' a informática que el fallo es real. ¡Grave error! Al hacerlo, te conviertes en un infractor. Debes detenerte inmediatamente y reportarlo al CISO o DPO.",
        "Ahora bien, ¿qué ocurre si reportas esta vulnerabilidad gravísima y tu superior decide ignorarla sistemáticamente, dejando la puerta abierta a un hackeo inminente? Aquí entra tu protección legal. La Ley 2/2023 (Protección del Informante) te permite escalar esta negligencia dolosa utilizando el Canal de Denuncias interno. Estás protegido legalmente contra el despido o cualquier represalia por informar de que la empresa no está cerrando una grieta que atenta contra el RGPD.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 60,
      "id": 101
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 100",
      "title": "Actuación ante una Brecha y el ENS",
      "visual_title": "Cuando el daño está hecho: Acción ante la Fuga y el ENS",
      "text_on_screen": [
        "• Contención: Aislar sistemas comprometidos para detener la sangría de datos.",
        "• Activación del Comité de Crisis: Informar de inmediato a la Alta Dirección, al equipo Legal y al DPO.",
        "• Esquema Nacional de Seguridad (ENS): Si la brecha afecta a datos del Sector Público (ej. servicios a Ayuntamientos o Ministerios), el protocolo exige una categorización técnica de impacto estricta (Básico, Medio, Alto) y la participación de los operadores estatales.",
        "• Clasificación del Impacto: El DPO debe evaluar qué tipo de datos han sido expuestos y cuántos usuarios están afectados. Esta evaluación marca el camino legal a seguir."
      ],
      "extended_text": [
        "\"El escenario cambia drásticamente si lo que detectas es una Brecha de Datos. Por ejemplo, te llama un cliente para decirte que ha encontrado su base de datos publicada en la Dark Web.",
        "El primer paso siempre es la contención: informática debe aislar los servidores afectados para que no se extraiga ni un megabyte más. En paralelo, se convoca al Comité de Crisis. Si nuestra empresa trabaja para la Administración Pública, entramos en el terreno del Esquema Nacional de Seguridad (ENS). No podemos tratar el incidente como un mero problema interno; debemos seguir la categorización de impacto dictada por el Estado, ya que una fuga en nuestros sistemas puede comprometer la seguridad nacional o los datos tributarios de los ciudadanos. El DPO asume el mando legal y determina la gravedad real de lo que se ha robado.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 60,
      "id": 102
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 101",
      "title": "Legislación Vigente y el Reloj de Arena",
      "visual_title": "La Ley Española: El Plazo Implacable de las 72 Horas",
      "text_on_screen": [
        "• Artículo 33 del RGPD / LOPDGDD: La empresa está obligada legalmente a notificar la brecha de datos a la autoridad de control sin dilación indebida.",
        "• El Cronómetro de las 72 Horas: El plazo legal máximo es de 72 horas desde que la empresa tiene constancia cierta de la brecha de seguridad.",
        "• Qué debe incluir la notificación inicial:",
        "Naturaleza y volumen de los datos afectados.",
        "Datos de contacto del DPO.",
        "Posibles consecuencias y medidas correctivas."
      ],
      "extended_text": [
        "\"En el mismo segundo en que la empresa tiene constancia de que los datos personales se han visto comprometidos, se pone en marcha un cronómetro legal implacable. El Artículo 33 del Reglamento General de Protección de Datos dicta que tenemos un máximo absoluto de 72 horas para notificar el incidente a las autoridades.",
        "Este plazo no entiende de fines de semana ni de festivos. Si un empleado sufre un robo de credenciales un viernes por la tarde y lo oculta por miedo a represalias hasta el martes siguiente, el plazo legal de 72 horas habrá expirado. Cuando la empresa lo descubra y lo reporte, la autoridad competente aplicará sanciones multimillonarias por negligencia y ocultación, independientemente del daño causado por el hacker. La transparencia temprana es nuestro único salvavidas.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 60,
      "id": 103
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 102",
      "title": "Agencias y Protocolos de Notificación en España",
      "visual_title": "¿A quién hay que notificar? El Ecosistema Nacional",
      "text_on_screen": [
        "• 1. AEPD (Agencia Española de Protección de Datos): Notificación OBLIGATORIA a través de su Sede Electrónica (formulario \"Comunica-Brecha\") si afecta a datos personales.",
        "• 2. INCIBE-CERT: (Instituto Nacional de Ciberseguridad). Para la gestión técnica del incidente. Otorga soporte y mitigación a empresas y ciudadanos.",
        "• 3. CCN-CERT: El Centro Criptológico Nacional. Notificación OBLIGATORIA según el ENS si la empresa provee servicios a la Administración Pública o es un Operador Crítico.",
        "• 4. Fuerzas y Cuerpos de Seguridad: Denuncia penal por extorsión o robo."
      ],
      "extended_text": [
        "\"En España, la notificación no se hace 'al gobierno' en general, sino a agencias muy específicas. Si hay datos de personas involucrados, el actor principal es la Agencia Española de Protección de Datos (AEPD), a quienes rendimos cuentas en esas primeras 72 horas.",
        "Simultáneamente, contactamos con INCIBE-CERT, que son los 'bomberos digitales' de España; nos ayudan a entender el virus y evitar que el ataque se expanda. Sin embargo, si los datos comprometidos pertenecen al sector público (ENS), tenemos el deber ineludible de coordinarnos con el CCN-CERT (Centro Criptológico Nacional), el organismo encargado de proteger la infraestructura digital del Estado. Finalmente, si hay un chantaje económico, el equipo legal presentará la denuncia ante la Unidad de Delitos Telemáticos de las Fuerzas y Cuerpos de Seguridad.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 60,
      "id": 104
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 103",
      "title": "La Notificación a los Afectados (Art. 34)",
      "visual_title": "Dar la Cara: Cuándo avisar al Cliente",
      "text_on_screen": [
        "• Artículo 34 del RGPD: Comunicación al interesado.",
        "• El Criterio de Riesgo Alto: Si el DPO determina que la brecha supone un \"alto riesgo para los derechos y libertades de las personas físicas\", la empresa debe notificar a los afectados directamente.",
        "• El objetivo: Permitir que el usuario tome medidas urgentes (cancelar tarjetas, cambiar contraseñas, estar alerta ante intentos de extorsión)."
      ],
      "extended_text": [
        "\"Notificar a la AEPD es un trámite institucional, pero hay una obligación aún más delicada: dar la cara ante nuestros clientes o empleados. El Artículo 34 del RGPD establece que si la fuga de datos incluye información sensible (contraseñas en texto claro, datos bancarios, datos de salud), el riesgo para la vida de esas personas es alto.",
        "En ese caso, la ley nos obliga a enviar una comunicación directa y en un lenguaje claro a cada uno de los afectados. No podemos ocultarlo bajo un comunicado confuso en la página web. Debemos enviarles un correo directo explicando qué ha pasado, qué datos suyos tienen los criminales y, lo más importante, qué pasos deben dar para protegerse. Ocultar la brecha a los usuarios para 'salvar la imagen de la marca' es la infracción más grave contemplada por la legislación europea.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 60,
      "id": 105
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 104",
      "title": "Casos Reales - La Ocultación Sancionada",
      "visual_title": "Casos Reales: El Precio de Ocultar la Verdad",
      "text_on_screen": [
        "• Ejemplo de Infracción (Caso Globalia / Air Europa):",
        "• La Brecha: Sufrieron un ciberataque masivo que expuso tarjetas de crédito y datos personales de cientos de miles de clientes.",
        "• El Error Fatal: La compañía tardó semanas en notificar a la AEPD y a los clientes, intentando gestionar la crisis de forma opaca.",
        "• La Consecuencia: La AEPD impuso una de las multas más severas en España, no tanto por el hackeo en sí, sino por la flagrante vulneración del plazo de 72 horas y la desprotección de los ciudadanos."
      ],
      "extended_text": [
        "\"Lamentablemente, tenemos ejemplos en España de empresas que intentaron esconder sus incidentes. Un caso emblemático fue el de la aerolínea Air Europa. Sufrieron una brecha gravísima donde se expusieron los datos de las tarjetas de crédito de sus clientes.",
        "En lugar de activar el protocolo de emergencia, notificaron el incidente tarde, fuera de plazos, y demoraron enormemente el aviso directo a los pasajeros afectados. ¿Qué provocó esto? Que durante semanas, los ciberdelincuentes pudieron usar esas tarjetas libremente para realizar fraudes, porque los ciudadanos no sabían que debían cancelarlas. La AEPD no tuvo piedad. Este caso sentó jurisprudencia: la AEPD no te multará simplemente por ser víctima de un ataque sofisticado, te multará de forma devastadora si tu inacción o tus mentiras impiden a los usuarios defenderse.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 60,
      "id": 106
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 105",
      "title": "Justificación para Auditores (Compliance PRD-M7)",
      "visual_title": "Nota de Cumplimiento para Auditoría (PRD-M7)",
      "text_on_screen": [
        "(Documento oficial de evidencia normativa)",
        "• 1. RGPD (Art. 33 y 34): Procedimientos de notificación de violaciones de seguridad a la autoridad de control y al interesado.",
        "• 2. Directiva NIS2 y Esquema Nacional de Seguridad (ENS): Obligaciones estrictas de información sobre incidentes al ecosistema nacional (INCIBE/CCN-CERT) y gestión operativa de brechas.",
        "• 3. AI Act: Supervisión humana obligatoria en sistemas automatizados de triaje de vulnerabilidades.",
        "• 4. Ley 2/2023 (Whistleblowing): Garantías legales para empleados que reporten internamente la ocultación negligente de vulnerabilidades por parte de la organización."
      ],
      "extended_text": [
        "\"Este módulo se centra en la Resiliencia Corporativa. Ningún auditor esperará que nuestra empresa sea inmune a los ataques, pero exigirá pruebas documentales y formativas de que sabemos cómo reaccionar.",
        "Al completar esta formación, damos herramientas para que todos los estratos de la organización comprendan los plazos fatales del RGPD, que conozcan los canales legales en España (AEPD, CCN-CERT), y que la empresa ampare éticamente a sus trabajadores a través de la Ley 2/2023 frente a la ocultación de riesgos.\""
      ],
      "image_desc": null,
      "type": "content",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 60,
      "id": 107
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 106",
      "title": "Pregunta 1",
      "visual_title": "Quiz Módulo 7: Supera la Evaluación",
      "text_on_screen": [
        "(Esta pantalla bloquea el avance del alumno en el LMS hasta que responda correctamente).",
        "Pregunta 1: Un proveedor te avisa de que el software que utilizas tiene un \"agujero\" de seguridad por el que alguien podría colarse, aunque no ha habido ninguna fuga confirmada. ¿Cómo se define esto legalmente?",
        "• [A] Es una Brecha de Datos (Data Breach) masiva.",
        "• [B] Es una Vulnerabilidad. No hay fuga confirmada, pero requiere triaje y parcheo prioritario.",
        "• [C] Es un delito del proveedor que hay que denunciar a la Policía."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 45,
      "question_text": "Un proveedor te avisa de que el software que utilizas tiene un \"agujero\" de seguridad por el que alguien podría colarse, aunque no ha habido ninguna fuga confirmada. ¿Cómo se define esto legalmente?",
      "options": [
        {
          "id": "A",
          "text": "Es una Brecha de Datos (Data Breach) masiva."
        },
        {
          "id": "B",
          "text": "Es una Vulnerabilidad. No hay fuga confirmada, pero requiere triaje y parcheo prioritario."
        },
        {
          "id": "C",
          "text": "Es un delito del proveedor que hay que denunciar a la Policía."
        }
      ],
      "correct_answer": "B",
      "feedback": "Una falla en el sistema que aún no ha sido explotada es una Vulnerabilidad. Si los atacantes la aprovechan para robar información, se convertirá en una Brecha de Datos. •",
      "id": 108
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 107",
      "title": "Pregunta 2",
      "visual_title": "Quiz Módulo 7: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 2: Se confirma que los datos de nuestros clientes han sido robados. ¿Cuál es el tiempo MÁXIMO que tiene la empresa por ley para notificarlo a la AEPD?",
        "• [A] 72 horas desde que la empresa tiene constancia cierta del incidente.",
        "• [B] 15 días hábiles para dar tiempo a realizar una investigación forense completa.",
        "• [C] 24 horas, pero solo si es horario de oficina."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 45,
      "question_text": "Se confirma que los datos de nuestros clientes han sido robados. ¿Cuál es el tiempo MÁXIMO que tiene la empresa por ley para notificarlo a la AEPD?",
      "options": [
        {
          "id": "A",
          "text": "72 horas desde que la empresa tiene constancia cierta del incidente."
        },
        {
          "id": "B",
          "text": "15 días hábiles para dar tiempo a realizar una investigación forense completa."
        },
        {
          "id": "C",
          "text": "24 horas, pero solo si es horario de oficina."
        }
      ],
      "correct_answer": "A",
      "feedback": "El RGPD y la LOPDGDD son tajantes: el reloj marca un límite de 72 horas innegociables para reportar a las autoridades una vez constatado el incidente. Ocultarlo es el camino directo a las multas millonarias. •",
      "id": 109
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 108",
      "title": "Pregunta 3",
      "visual_title": "Quiz Módulo 7: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 3: Ante la noticia de la brecha de datos con tarjetas de crédito involucradas, el equipo directivo sugiere no avisar a los usuarios afectados para \"evitar salir en las noticias\". ¿Es esto correcto según la ley española?",
        "• [A] Sí, la imagen corporativa es lo primero.",
        "• [B] No. Si la brecha supone un alto riesgo para los derechos y libertades de las personas, el Art. 34 del RGPD obliga a notificar directamente a los afectados para que puedan protegerse.",
        "• [C] Sí, el ENS prohíbe hablar con los clientes."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 45,
      "question_text": "Ante la noticia de la brecha de datos con tarjetas de crédito involucradas, el equipo directivo sugiere no avisar a los usuarios afectados para \"evitar salir en las noticias\". ¿Es esto correcto según la ley española?",
      "options": [
        {
          "id": "A",
          "text": "Sí, la imagen corporativa es lo primero."
        },
        {
          "id": "B",
          "text": "No. Si la brecha supone un alto riesgo para los derechos y libertades de las personas, el Art. 34 del RGPD obliga a notificar directamente a los afectados para que puedan protegerse."
        },
        {
          "id": "C",
          "text": "Sí, el ENS prohíbe hablar con los clientes."
        }
      ],
      "correct_answer": "B",
      "feedback": "Ocultar una brecha de alto riesgo es la infracción más castigada. Los usuarios deben ser avisados inmediatamente para que puedan cancelar tarjetas o cambiar contraseñas. •",
      "id": 110
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 109",
      "title": "Pregunta 4",
      "visual_title": "Quiz Módulo 7: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 4: Tu empresa decide utilizar una herramienta de Inteligencia Artificial para decidir automáticamente qué vulnerabilidades informáticas parchear y cuáles ignorar. Según el AI Act, ¿es esto suficiente?",
        "• [A] Sí, porque las IAs son más rápidas y no cometen errores.",
        "• [B] No. La ley europea exige que siempre exista una supervisión humana significativa (triaje) que valide las decisiones de la IA, especialmente si hay datos personales en riesgo.",
        "• [C] Sí, siempre que la IA se haya comprado en Europa."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 45,
      "question_text": "Tu empresa decide utilizar una herramienta de Inteligencia Artificial para decidir automáticamente qué vulnerabilidades informáticas parchear y cuáles ignorar. Según el AI Act, ¿es esto suficiente?",
      "options": [
        {
          "id": "A",
          "text": "Sí, porque las IAs son más rápidas y no cometen errores."
        },
        {
          "id": "B",
          "text": "No. La ley europea exige que siempre exista una supervisión humana significativa (triaje) que valide las decisiones de la IA, especialmente si hay datos personales en riesgo."
        },
        {
          "id": "C",
          "text": "Sí, siempre que la IA se haya comprado en Europa."
        }
      ],
      "correct_answer": "B",
      "feedback": "El AI Act prohíbe delegar el 100% de la responsabilidad de seguridad y clasificación de riesgos a una máquina autónoma. El criterio humano es imprescindible para la validación final. •",
      "id": 111
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 110",
      "title": "Pregunta 5",
      "visual_title": "Quiz Módulo 7: Supera la Evaluación",
      "text_on_screen": [
        "Pregunta 5: Tu empresa trabaja con datos de la Administración Pública. Ocurre una brecha de seguridad grave, pero la Dirección decide no informar al Estado. Como empleado, ¿qué herramienta te protege si decides reportar internamente esta negligencia sistemática?",
        "• [A] Ninguna, porque el empleado tiene prohibido cuestionar al director.",
        "• [B] El Canal de Denuncias interno amparado por la Ley 2/2023 (Protección del Informante), que garantiza el anonimato y protege frente a represalias por reportar infracciones del Esquema Nacional de Seguridad (ENS).",
        "• [C] Escribir a la prensa de forma anónima."
      ],
      "extended_text": [],
      "image_desc": null,
      "type": "quiz_question",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 45,
      "question_text": "Tu empresa trabaja con datos de la Administración Pública. Ocurre una brecha de seguridad grave, pero la Dirección decide no informar al Estado. Como empleado, ¿qué herramienta te protege si decides reportar internamente esta negligencia sistemática?",
      "options": [
        {
          "id": "A",
          "text": "Ninguna, porque el empleado tiene prohibido cuestionar al director."
        },
        {
          "id": "B",
          "text": "El Canal de Denuncias interno amparado por la Ley 2/2023 (Protección del Informante), que garantiza el anonimato y protege frente a represalias por reportar infracciones del Esquema Nacional de Seguridad (ENS)."
        },
        {
          "id": "C",
          "text": "Escribir a la prensa de forma anónima."
        }
      ],
      "correct_answer": "B",
      "feedback": "Faltar a las obligaciones del Esquema Nacional de Seguridad (ENS) es gravísimo. La Ley 2/2023 blinda a los empleados que levantan la mano ante ocultaciones dolosas o negligencias corporativas. \"Enhorabuena, has finalizado el Módulo 7 y con ello, todo el ciclo integral de la Prevención y Reacción frente a Riesgos Digitales. Ahora entiendes no solo cómo proteger la información en tu día a día, sino cómo el marco legal español y europeo actúa frente a las peores crisis. Recuerda: la transparencia, la rapidez y el cumplimiento de los protocolos son la mejor armadura corporativa.\"",
      "id": 112
    },
    {
      "module_id": 7,
      "slide_num_str": "Diapositiva 111",
      "title": "Resultados y Feedback del Módulo 7",
      "visual_title": "Corrección y Retroalimentación: Módulo 7",
      "text_on_screen": [
        "• Q1: Correcta [B] - Feedback: Una falla en el sistema que aún no ha sido explotada es una Vulnerabilidad. Si los atacantes la aprovechan para robar información, se convertirá en una Brecha de Datos.",
        "• Q2: Correcta [A] - Feedback: El RGPD y la LOPDGDD son tajantes: el reloj marca un límite de 72 horas innegociables para reportar a las autoridades una vez constatado el incidente. Ocultarlo es el camino directo a las multas millonarias.",
        "• Q3: Correcta [B] - Feedback: Ocultar una brecha de alto riesgo es la infracción más castigada. Los usuarios deben ser avisados inmediatamente para que puedan cancelar tarjetas o cambiar contraseñas.",
        "• Q4: Correcta [B] - Feedback: El AI Act prohíbe delegar el 100% de la responsabilidad de seguridad y clasificación de riesgos a una máquina autónoma. El criterio humano es imprescindible para la validación final.",
        "• Q5: Correcta [B] - Feedback: Faltar a las obligaciones del Esquema Nacional de Seguridad (ENS) es gravísimo. La Ley 2/2023 blinda a los empleados que levantan la mano ante ocultaciones dolosas o negligencias corporativas."
      ],
      "extended_text": [
        "\"Enhorabuena, has finalizado el Módulo 7 y con ello, todo el ciclo integral de la Prevención y Reacción frente a Riesgos Digitales. Ahora entiendes no solo cómo proteger la información en tu día a día, sino cómo el marco legal español y europeo actúa frente a las peores crisis. Recuerda: la transparencia, la rapidez y el cumplimiento de los protocolos son la mejor armadura corporativa.\""
      ],
      "image_desc": null,
      "type": "quiz_feedback",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 0,
      "id": 113
    },
    {
      "module_id": 7,
      "slide_num_str": "FINAL",
      "title": "Certificación y Cierre",
      "visual_title": "FINAL: Enhorabuena y Certificación Oficial",
      "text_on_screen": [
        "ENHORABUENA: Has completado con éxito el Plan de Resiliencia Digital.",
        "El Impacto: Gracias a tu compromiso y atención, tu organización es hoy mucho más segura, más resiliente y más humana.",
        "Siguiente paso: En unos instantes, tras la validación de tu código y DNI en la plataforma, recibirás tu Certificado Digital Firmado.",
        "Este documento acredita de forma oficial tu formación ante los marcos legales vigentes (NIS2, RGPD, PRL)."
      ],
      "extended_text": [
        "\"Hemos llegado al final de este viaje. La ciberseguridad, como hemos comprobado, no es un producto que la empresa pueda comprar e instalar; es una cultura que se construye día a día, clic a clic. Al entender el marco legal, conocer tus propias vulnerabilidades cognitivas, dominar los derechos de privacidad y saber cómo responder de forma calmada y transparente ante un incidente, te has convertido en la línea de defensa más formidable que posee esta organización.",
        "Enhorabuena por tu dedicación. Puedes cerrar esta ventana para generar y descargar tu Certificado Acreditativo Oficial.\""
      ],
      "image_desc": null,
      "type": "final",
      "is_range": false,
      "module_title": "Gestión de Vulnerabilidades y Brechas",
      "time": 0,
      "id": 114
    }
  ]
};
